#!/usr/bin/env python3
"""Read-only gate of component and exact combined root synthesis evidence."""
from pathlib import Path
import hashlib,json,re
HERE=Path(__file__).resolve().parent
RUN=HERE.parents[1]/'full-sweep-texture'
BASE=HERE.parents[2]/'timing-next/physical-corrected-cache-mixer/work/master/src/fpga/targets/pocket/output_files/ap_core.map.rpt'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def params(text,name):
    start=text.index('; Parameter Settings for Inferred Entity Instance: '+name+' ;')
    end=text.index('Note: In order',start)
    return {m.group(1).strip():m.group(2).strip()for m in re.finditer(r'^; ([^;]+); ([^;]+);',text[start:end],re.M)}
def resource(text,name):
    for line in text.splitlines():
        fields=[x.strip()for x in line.split(';')]
        if len(fields)>2 and fields[1]==name:return int(fields[2].replace(',',''))
    raise AssertionError(name)
def main():
    manifest=json.loads((RUN/'manifest.json').read_text());receipt=json.loads((RUN/'map-receipt.json').read_text());assert receipt['state']=='complete'
    project=RUN/'work/master/src/fpga/targets/pocket';rpt=project/'output_files/ap_core.map.rpt';text=rpt.read_text(errors='replace')
    name='core_top:ic|gpu_core:gpu|altsyncram:tex_stream.requests_rtl_0';ps=params(text,name)
    required={'OPERATION_MODE':'DUAL_PORT','WIDTH_A':'27','WIDTH_B':'27','WIDTHAD_A':'2','WIDTHAD_B':'2','NUMWORDS_A':'4','NUMWORDS_B':'4','RAM_BLOCK_TYPE':'M10K','ADDRESS_REG_B':'CLOCK0','OUTDATA_REG_B':'UNREGISTERED','READ_DURING_WRITE_MODE_MIXED_PORTS':'DONT_CARE'}
    for k,v in required.items():assert ps[k]==v,(k,ps[k])
    tdf=project/'db'/f"{ps['CBXI_PARAMETER']}.tdf";tdftxt=tdf.read_text()
    assert '--synthesis_resources = M10K 1 ' in tdftxt
    assert 'PORT_B_ADDRESS_CLOCK = "clock1"' in tdftxt and 'PORT_B_DATA_OUT_CLOCK =' not in tdftxt
    assert 'ram_block1a[26..0].clk1 = clock0;' in tdftxt
    assert 'ram_block1a[26..0].clk0 = clock0;' in tdftxt
    assert 'ram_block1a[26..0].portbre = B"111111111111111111111111111";' in tdftxt
    gpu=RUN/'frozen/src/fpga/common/os30/gpu_core.v';assert sha(gpu)==sha(HERE/'gpu_core.v')=='dc1298bb26c62dc682496b276c405f06069389a1d6468e86c4bc89103ac78656'
    queue=json.loads((HERE/'queue-lockstep/receipt.json').read_text());replay=json.loads((HERE/'full-write-path-poison/receipt.json').read_text());assert queue['passed'] and replay['passed']
    component=HERE/'output_files/request.map.rpt';ct=component.read_text(errors='replace');cp=params(ct,'request_candidate:candidate|altsyncram:requests_rtl_0')
    for k,v in required.items():assert cp[k]==v
    def entity(t,name):
        row=next(l for l in t.splitlines()if re.match(r';\s+\|'+re.escape(name)+r'\|',l));fields=[x.strip()for x in row.split(';')];return dict(ALUT=int(fields[2].split()[0]),FF=int(fields[3].split()[0]),RAM_bits=int(fields[4]))
    entities={n:entity(ct,'request_'+n+':'+n)for n in ['parent','candidate']}
    assert entities=={'parent':{'ALUT':30,'FF':55,'RAM_bits':0},'candidate':{'ALUT':30,'FF':28,'RAM_bits':108}}
    baseline=BASE.read_text(errors='replace');keys=['Estimate of Logic utilization (ALMs needed)','Combinational ALUT usage for logic','Memory ALUT usage','Dedicated logic registers','Total MLAB memory bits','Total block memory bits']
    resources={k:dict(parent=resource(baseline,k),candidate=resource(text,k),delta=resource(text,k)-resource(baseline,k))for k in keys}
    r={'passed':True,'status':'GPU_QUALIFIED_FOR_FULL_PHYSICAL_SWEEP','candidate_sha256':sha(gpu),'combined_source_fingerprint':manifest['frozen_sha256'],'combined_map_receipt_sha256':sha(RUN/'map-receipt.json'),'map_report_sha256':sha(rpt),'baseline_map_sha256':sha(BASE),'primitive_tdf_sha256':sha(tdf),'m10k_blocks':1,'required_parameters':required,'source_read_schedule':'Unconditional one-clock next-head prefetch. Original explicit same-address forwarding selects the new registered data whenever the raw mixed-port result is undefined. Queue depths, pointers, credit counts, payload and read/accept cycles unchanged.','component_comparison':entities,'component_report_sha256':sha(component),'whole_core_combined_three_migrations_resources':resources,'queue_lockstep_receipt_sha256':sha(HERE/'queue-lockstep/receipt.json'),'actual_gpu_writepath_receipt_sha256':sha(HERE/'full-write-path-poison/receipt.json'),'timing_or_fit_claim':False,'quartus_full_fits_launched':0,'recipe_sha256':sha(Path(__file__))}
    (HERE/'inference-qualification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
