#!/usr/bin/env python3
"""Pin the deployed archive and exact single request-memory attribute change."""
from pathlib import Path
import hashlib,json,re,tarfile
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[5]
PACKAGE=REPO/'tools/experiments/quake2_tiny_audio_timing_20261013/core'
BASE=HERE.parents[2]/'timing-next/physical-corrected-cache-mixer/frozen'
REL='src/fpga/common/os30/gpu_core.v'
def sha(x):return hashlib.sha256(x).hexdigest()
def main():
    m=json.loads((PACKAGE/'source-manifest.json').read_text());pins=m['source_sha256'];archive=PACKAGE/'source.tar.gz'
    assert sha(archive.read_bytes())==m['source_archive_sha256']
    with tarfile.open(archive,'r:gz')as tf:contents={f.name:tf.extractfile(f).read()for f in tf.getmembers()if f.isfile()}
    assert {n:sha(b)for n,b in contents.items()}==pins
    assert {str(p.relative_to(BASE)):sha(p.read_bytes())for p in BASE.rglob('*')if p.is_file()}==pins
    assert sha(json.dumps(pins,sort_keys=True,separators=(',',':')).encode())==m['frozen_sha256']=='9a4e8b063a2ac21c59d7dbfc47335155760666d22b10095dda27559573329a87'
    old=contents[REL].decode();new=(HERE/'gpu_core.v').read_text()
    line='    (* ramstyle = "MLAB, no_rw_check" *) reg [REQ_W-1:0] requests [0:3];'
    assert old.count(line)==2 and old.replace(line,line.replace('MLAB','M10K'),1)==new
    strip=lambda s:re.sub(r'\(\*.*?\*\)','',s,flags=re.S)
    assert strip(old)==strip(new)
    # Data-independent control proof, independently bit-blasted over every bit
    # and all old/new/undefined-raw values. Bypass masks any collision result.
    checks=0
    for rd in range(4):
      for wr in range(4):
       for pop in [0,1]:
        for push in [0,1]:
         alias=push and wr==((rd+pop)&3)
         for bit in range(27):
          for oldbit in [0,1]:
           for newbit in [0,1]:
            for poison in [0,1]:
             raw=poison if alias else oldbit
             actual=newbit if alias else raw
             expected=newbit if alias else oldbit
             assert actual==expected;checks+=1
    r={'passed':True,'deployed_source_fingerprint':m['frozen_sha256'],'deployed_source_archive_sha256':m['source_archive_sha256'],'deployed_file_count':len(pins),'all_frozen_files_match_deployed_archive':True,'active_path':REL,'parent_sha256':pins[REL],'candidate_sha256':sha(new.encode()),'one_attribute_only':True,'attribute_stripped_bytes_exact':True,'framebuffer_results_metadata_queues_unchanged':True,'bit_blasted_forwarding_checks':checks,'undefined_collision_raw_values_both_checked':True,'no_ISA_Dock_audio_changes':True,'recipe_sha256':sha(Path(__file__).read_bytes())}
    (HERE/'source-qualification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
