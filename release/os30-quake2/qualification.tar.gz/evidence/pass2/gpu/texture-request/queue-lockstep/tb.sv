
module tb;
reg clk=0;always #5 clk=~clk;
reg reset_n=0,soft_reset=0;
reg[1:0]state=1;
reg p0_valid=0,p0a_valid=0,tex_req_ready=0,tex_resp_valid=0;
reg[15:0]tex_resp_data=0;reg[25:0]fp_tex_addr_full=0;
reg sp_truecolor=0;reg[109:0]p0_tex_meta=0;reg stream_result_pop=0;
wire la,pa,va,ta,wa,lb,pb,vb,tb_,wb;
wire[125:0]ra,rb;wire[25:0]aa,ab;
queue_parent a(clk,reset_n,soft_reset,state,p0_valid,p0a_valid,tex_req_ready,tex_resp_valid,tex_resp_data,fp_tex_addr_full,sp_truecolor,p0_tex_meta,stream_result_pop,la,pa,va,ra,ta,aa,wa);
queue_candidate b(clk,reset_n,soft_reset,state,p0_valid,p0a_valid,tex_req_ready,tex_resp_valid,tex_resp_valid?tex_resp_data:16'hcafe,fp_tex_addr_full,sp_truecolor,p0_tex_meta,stream_result_pop,lb,pb,vb,rb,tb_,ab,wb);
reg[31:0]rng=32'h12345678;
function automatic[31:0]step(input[31:0]v);reg[31:0]t;begin t=v^(v<<13);t=t^(t>>17);step=t^(t<<5);end endfunction
integer t,phase;
integer pushes=0,pops=0,responses=0,forwards=0,request_stalls=0,result_stalls=0,full_request=0,full_result=0,wraps=0,resets=0,checks=0;
reg queued_launch=0,pending=0,next_launch,next_pending;
initial begin
repeat(3)@(negedge clk);
reset_n=1;
for(t=0;t<200000;t=t+1)begin
    rng=step(rng);phase=t%1024;
    soft_reset=(t%8191==8190);
    reset_n=(t%32767!=32766);
    p0_valid=queued_launch;
    p0a_valid=(phase<256)||rng[0];
    tex_req_ready=(phase>=64)&&rng[1];
    tex_resp_valid=pending&&(phase>=128)&&rng[2];
    stream_result_pop=va&&(phase>=192)&&rng[3];
    tex_resp_data=rng[31:16];fp_tex_addr_full=rng[25:0];sp_truecolor=rng[26];
    p0_tex_meta={rng,rng^32'h7fefabcd,rng+32'h76543210,rng[13:0]};
    if(!reset_n||soft_reset)begin p0_valid=0;p0a_valid=0;tex_resp_valid=0;stream_result_pop=0;tex_req_ready=0;end
    #1;
    next_launch=la;
    next_pending=(ta&&tex_req_ready)?1:((tex_resp_valid)?0:pending);
    if(!reset_n||soft_reset)begin next_launch=0;next_pending=0;resets=resets+1;end
    if(a.req_push)pushes=pushes+1;
    if(a.req_pop)pops=pops+1;
    if(a.res_push)responses=responses+1;
    if(a.req_push&&a.req_wr==a.req_next)forwards=forwards+1;
    if(ta&&!tex_req_ready)request_stalls=request_stalls+1;
    if(va&&!stream_result_pop)result_stalls=result_stalls+1;
    if(a.req_count==4)full_request=full_request+1;
    if(a.res_reserved==4)full_result=full_result+1;
    if(a.req_push&&a.req_wr==3)wraps=wraps+1;
    @(posedge clk);#1;
    assert({la,pa,va,ta,wa}==={lb,pb,vb,tb_,wb})else $fatal(1,"visible flags cycle %d",t);
    if(ta)assert({aa,wa}==={ab,wb})else $fatal(1,"request head cycle %d",t);
    if(va)assert(ra===rb)else $fatal(1,"result/meta head cycle %d",t);
    assert({a.req_rd,a.req_wr,a.req_count,a.req_reserved,a.res_rd,a.res_wr,a.res_count,a.res_reserved,a.meta_rd,a.meta_wr,a.lookup_pending}==={b.req_rd,b.req_wr,b.req_count,b.req_reserved,b.res_rd,b.res_wr,b.res_count,b.res_reserved,b.meta_rd,b.meta_wr,b.lookup_pending})else $fatal(1,"queue state cycle %d",t);
    assert(a.req_count<=4&&a.req_reserved<=4&&a.res_count<=4&&a.res_reserved<=4)else $fatal(1,"testbench credit discipline %d",t);
    queued_launch=next_launch;pending=next_pending;checks=checks+1;
    @(negedge clk);
end
assert(pushes>10000&&pops>10000&&responses>10000&&forwards>100&&request_stalls>100&&result_stalls>100&&full_request>100&&full_result>100&&wraps>100&&resets>10);
$display("PASS cycles=%0d pushes=%0d pops=%0d responses=%0d collision_forwards=%0d request_stalls=%0d result_stalls=%0d full_request=%0d full_result=%0d wraps=%0d resets=%0d",checks,pushes,pops,responses,forwards,request_stalls,result_stalls,full_request,full_result,wraps,resets);
$finish;
end
endmodule
