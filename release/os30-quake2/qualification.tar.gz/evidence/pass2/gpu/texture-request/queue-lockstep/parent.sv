module queue_parent(input clk,reset_n,soft_reset,input[1:0]state,input p0_valid,p0a_valid,
input tex_req_ready,tex_resp_valid,input[15:0]tex_resp_data,
input[25:0]fp_tex_addr_full,input sp_truecolor,input[109:0]p0_tex_meta,
input stream_result_pop,output stream_launch,stream_pending,stream_result_valid,
output[125:0]stream_result,output tex_req_valid,output[25:0]tex_req_addr,output tex_req_wide);
localparam GPU_ADDR_W=26,TEX_META_W=110,SINGLE_CLIP_VERTEX=1,S_FRAG_PIPE=1;
    localparam REQ_W = GPU_ADDR_W + 1;
`ifdef INCLUDE_TEX_QUEUE_MLAB
    // Same RTL in MLABs (registered reads in LAB flops): for builds with no
    // M10K to spare, ~9 MLABs instead of the 14 the combined-entry MLAB form
    // needs, and without its 110-bit lookup copy.
    (* ramstyle = "MLAB, no_rw_check" *) reg [REQ_W-1:0] requests [0:3];
    (* ramstyle = "MLAB, no_rw_check" *) reg [15:0] results [0:3];
    localparam META_IN_MLAB = !SINGLE_CLIP_VERTEX;
`else
    (* ramstyle = "M10K, no_rw_check" *) reg [REQ_W-1:0] requests [0:3];
    (* ramstyle = "M10K, no_rw_check" *) reg [15:0] results [0:3];
    localparam META_IN_MLAB = 0;
`endif
    reg [1:0] req_rd, req_wr, res_rd, res_wr;
    reg [2:0] meta_rd, meta_wr;
    reg [2:0] req_count, req_reserved, res_count, res_reserved;
    reg lookup_pending;
    reg lookup_wide;
    wire req_push = (state == S_FRAG_PIPE) && p0_valid;
    wire req_pop = tex_req_valid && tex_req_ready;
    wire res_push = lookup_pending && tex_resp_valid;
    wire [15:0] res_data = lookup_wide ? tex_resp_data : {8'd0, tex_resp_data[7:0]};
    // Prefetch the head used after this edge. A same-address write forwards
    // the newly enqueued word, including the first push into an empty queue.
    wire [1:0] req_next = req_rd + {1'b0, req_pop};
    wire [1:0] res_next = res_rd + {1'b0, stream_result_pop};
    wire [2:0] meta_next = meta_rd + {2'b0, stream_result_pop};
    reg [REQ_W-1:0] req_raw, req_forward;
    reg [15:0] res_raw, res_forward;
    reg [TEX_META_W-1:0] meta_raw;
    reg req_forward_valid, res_forward_valid;
    // Single-vertex projection releases three coordinate M10Ks. Reuse them
    // for this wide FIFO; the read/write schedule and queue depth stay identical.
    if (META_IN_MLAB) begin : meta_mlab
        (* ramstyle = "MLAB, no_rw_check" *) reg [TEX_META_W-1:0] metas [0:7];
        always @(posedge clk) begin
            if (req_push) metas[meta_wr] <= p0_tex_meta;
            meta_raw <= metas[meta_next];
        end
    end else begin : meta_m10k
        (* ramstyle = "M10K, no_rw_check" *) reg [TEX_META_W-1:0] metas [0:7];
        always @(posedge clk) begin
            if (req_push) metas[meta_wr] <= p0_tex_meta;
            meta_raw <= metas[meta_next];
        end
    end
    always @(posedge clk) begin
        req_raw <= requests[req_next];
        res_raw <= results[res_next];
        req_forward <= {fp_tex_addr_full, sp_truecolor};
        res_forward <= res_data;
        req_forward_valid <= req_push && (req_wr == req_next);
        res_forward_valid <= res_push && (res_wr == res_next);
    end
    wire [REQ_W-1:0] req_head = req_forward_valid ? req_forward : req_raw;
    assign stream_result = {meta_raw, res_forward_valid ? res_forward : res_raw};

    assign stream_launch = (state == S_FRAG_PIPE) && p0a_valid
                        && (req_reserved < 3'd4);
    assign stream_pending = (req_reserved != 0) || (res_reserved != 0);
    assign stream_result_valid = (res_count != 0);
    assign tex_req_valid = (state == S_FRAG_PIPE) && (req_count != 0)
                        && (res_reserved < 3'd4)
                        && (!lookup_pending || tex_resp_valid);
    assign {tex_req_addr, tex_req_wide} = req_head;

    always @(posedge clk) begin
        if (req_push) begin
            requests[req_wr] <= {fp_tex_addr_full, sp_truecolor};
        end
        if (res_push)
            results[res_wr] <= res_data;
        if (!reset_n || soft_reset) begin
            req_rd <= 0; req_wr <= 0; res_rd <= 0; res_wr <= 0;
            meta_rd <= 0; meta_wr <= 0;
            req_count <= 0; req_reserved <= 0;
            res_count <= 0; res_reserved <= 0;
            lookup_pending <= 0;
        end else begin
            req_count <= req_count + {2'd0, req_push} - {2'd0, req_pop};
            req_reserved <= req_reserved + {2'd0, stream_launch} - {2'd0, req_pop};
            res_count <= res_count + {2'd0, res_push} - {2'd0, stream_result_pop};
            res_reserved <= res_reserved + {2'd0, req_pop} - {2'd0, stream_result_pop};
            if (req_push) begin
                req_wr <= req_wr + 1'b1;
                meta_wr <= meta_wr + 1'b1;
            end
            if (req_pop) begin
                req_rd <= req_rd + 1'b1;
                lookup_wide <= tex_req_wide;
                lookup_pending <= 1;
            end else if (res_push) lookup_pending <= 0;
            if (res_push) res_wr <= res_wr + 1'b1;
            if (stream_result_pop) begin
                res_rd <= res_rd + 1'b1;
                meta_rd <= meta_rd + 1'b1;
            end
        end
    end
endmodule
