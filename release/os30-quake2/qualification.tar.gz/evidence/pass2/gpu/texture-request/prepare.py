#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,difflib
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[2]/'timing-next/physical-corrected-cache-mixer/frozen/src/fpga/common/os30/gpu_core.v'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    old=BASE.read_text();assert sha(BASE)=='5359411b9af35fd4619da978c3f508997ae1c0a2ba3281512c50c5a1d1e4e217'
    line='    (* ramstyle = "MLAB, no_rw_check" *) reg [REQ_W-1:0] requests [0:3];'
    assert old.count(line)==2
    # Only the first occurrence is the INCLUDE_TEX_QUEUE_RAM/MLAB branch.
    new=old.replace(line,line.replace('MLAB','M10K'),1)
    (HERE/'gpu_core.v').write_text(new)
    (HERE/'source.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='deployed/gpu_core.v',tofile='texture-request/gpu_core.v')))
    fragments=[line,
       '    wire [1:0] req_next = req_rd + {1\'b0, req_pop};',
       '    reg [REQ_W-1:0] req_raw, req_forward;',
       '        req_raw <= requests[req_next];',
       '        req_forward <= {fp_tex_addr_full, sp_truecolor};',
       '        req_forward_valid <= req_push && (req_wr == req_next);',
       '    wire [REQ_W-1:0] req_head = req_forward_valid ? req_forward : req_raw;',
       '            requests[req_wr] <= {fp_tex_addr_full, sp_truecolor};']
    for f in fragments:assert f in old,f
    modules=[]
    for name,style in [('parent','MLAB'),('candidate','M10K')]:
        modules.append('''module request_%s(input clk,input[1:0]req_rd,req_wr,input req_pop,req_push,
input[25:0]fp_tex_addr_full,input sp_truecolor,output[26:0]head);
localparam REQ_W=27;
%s
%s
%s
reg req_forward_valid;
always @(posedge clk) begin
%s
%s
%s
    if(req_push) begin
%s
    end
end
%s
assign head=req_head;
endmodule
'''%(name,fragments[0].replace('MLAB',style),fragments[1],fragments[2],fragments[3],fragments[4],fragments[5],fragments[7],fragments[6]))
    top='''module request_compare(input clk,
input[1:0]parent_rd,parent_wr,candidate_rd,candidate_wr,
input parent_pop,parent_push,candidate_pop,candidate_push,
input[25:0]parent_addr,candidate_addr,input parent_wide,candidate_wide,
output[26:0]parent_head,candidate_head);
request_parent parent(clk,parent_rd,parent_wr,parent_pop,parent_push,parent_addr,parent_wide,parent_head);
request_candidate candidate(clk,candidate_rd,candidate_wr,candidate_pop,candidate_push,candidate_addr,candidate_wide,candidate_head);
endmodule
'''
    (HERE/'request_compare.v').write_text('\n'.join(modules)+top)
    (HERE/'request.qpf').write_text('PROJECT_REVISION = "request"\n')
    (HERE/'request.qsf').write_text('''set_global_assignment -name FAMILY "Cyclone V"
set_global_assignment -name DEVICE 5CEBA4F23C8
set_global_assignment -name TOP_LEVEL_ENTITY request_compare
set_global_assignment -name PROJECT_OUTPUT_DIRECTORY output_files
set_global_assignment -name VERILOG_FILE request_compare.v
set_global_assignment -name OPTIMIZATION_TECHNIQUE AREA
set_global_assignment -name NUM_PARALLEL_PROCESSORS 1
set_instance_assignment -name VIRTUAL_PIN ON -to *
''')
    r={'parent_sha256':sha(BASE),'candidate_sha256':sha(HERE/'gpu_core.v'),'only_delta':'INCLUDE_TEX_QUEUE_RAM && INCLUDE_TEX_QUEUE_MLAB requests ramstyle only; framebuffer queue unchanged','component_source_sha256':sha(HERE/'request_compare.v'),'exact_source_fragments':fragments,'parameter_REQ_W':27,'independent_inputs':True,'component_map_only':True,'recipe_sha256':sha(Path(__file__))}
    (HERE/'preparation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
