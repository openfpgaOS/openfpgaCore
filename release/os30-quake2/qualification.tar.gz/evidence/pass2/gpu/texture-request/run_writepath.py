#!/usr/bin/env python3
"""Verify an attribute-only GPU RAM migration using the actual write pipeline.

Pins the deployed source and prior full GPU/cache/arbiter/slave fixture. Adds
passive assertions for occupied-head/free-tail collision freedom, registered
AW capture/hold and coverage. Does not simulate vendor RAM or Pocket PHY.
"""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,time
HERE=Path(__file__).resolve().parent
EXP=HERE.parents[2]
BASE=EXP/'timing-next/cache-meta-routing/full-write-path'
DEPLOYED=EXP/'timing-next/physical-corrected-cache-mixer/frozen'
REPO=next(p for p in HERE.parents if (p/'AGENTS.md').exists() and (p/'src').is_dir()) if any((p/'AGENTS.md').exists() and (p/'src').is_dir() for p in HERE.parents) else HERE.parents[4]
CANDIDATE_SHA='dc1298bb26c62dc682496b276c405f06069389a1d6468e86c4bc89103ac78656'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(p):return {str(x.relative_to(p)):sha(x)for x in sorted(p.rglob('*'))if x.is_file()}
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
OBSERVER=r'''
// Test-only passive observer. These registers never feed design outputs.
integer pass2_reads=0, pass2_writes=0, pass2_ahead=0, pass2_simultaneous=0;
integer pass2_full=0, pass2_empty=0, pass2_wrap=0, pass2_hold=0, pass2_checked=0;
reg pass2_check=0;
reg [31:0] pass2_expected_aw;
always @(posedge clk) begin
    pass2_check <= reset_n && !soft_reset;
    if (reset_n && !soft_reset) begin
        pass2_checked <= pass2_checked+1;
        assert(fbwq_count <= 16) else $fatal(1,"queue occupancy invalid");
        assert(((fbwq_wr_ptr-fbwq_rd_ptr)&4'hf)==(fbwq_count&5'hf))
          else $fatal(1,"queue pointer/count invariant");
        if (fbwq_count==16) pass2_full<=pass2_full+1;
        if (fbwq_count==0) pass2_empty<=pass2_empty+1;
        if (fbwq_swap_now || fbwq_stage_drain_now) begin
            assert(fbwq_count<16) else $fatal(1,"write to full queue");
            pass2_writes<=pass2_writes+1;
            if(fbwq_wr_ptr==15)pass2_wrap<=pass2_wrap+1;
        end
        if (fbwq_start_now || fbwq_aw_ahead_issue) begin
            assert(fbwq_count>0) else $fatal(1,"read empty queue");
            assert(!((fbwq_swap_now || fbwq_stage_drain_now) && fbwq_rd_ptr==fbwq_wr_ptr))
              else $fatal(1,"observable read/write collision");
            pass2_expected_aw <= {{(32-GPU_ADDR_W){1'b0}},fbwq_addr[fbwq_rd_ptr]};
            pass2_reads<=pass2_reads+1;
            if(fbwq_aw_ahead_issue)pass2_ahead<=pass2_ahead+1;
            if(fbwq_swap_now || fbwq_stage_drain_now)pass2_simultaneous<=pass2_simultaneous+1;
        end else begin
            pass2_expected_aw<=m_wr_awaddr;
            pass2_hold<=pass2_hold+1;
        end
    end
end
always @(negedge clk) begin
    if(pass2_check)assert(m_wr_awaddr===pass2_expected_aw)
      else $fatal(1,"AW address changed latency or hold semantics");
end
integer pass2_tex_push=0,pass2_tex_pop=0,pass2_tex_forward=0,pass2_tex_hold=0,pass2_tex_check_count=0;
reg[3:0] pass2_tex_known=0;
reg[26:0] pass2_tex_expected;
reg pass2_tex_check=0;
always @(posedge clk) begin
    pass2_tex_check<=pass2_tex_known[tex_stream.req_next]
       ||(tex_stream.req_push && tex_stream.req_wr==tex_stream.req_next);
    if(tex_stream.req_push)begin
        pass2_tex_known[tex_stream.req_wr]<=1;
        pass2_tex_push<=pass2_tex_push+1;
    end
    if(tex_stream.req_pop)pass2_tex_pop<=pass2_tex_pop+1;
    if(tex_stream.req_push && tex_stream.req_wr==tex_stream.req_next)begin
        pass2_tex_expected<={fp_tex_addr_full,sp_truecolor};
        pass2_tex_forward<=pass2_tex_forward+1;
    end else pass2_tex_expected<=tex_stream.requests[tex_stream.req_next];
    if(tex_req_valid && !tex_req_ready)pass2_tex_hold<=pass2_tex_hold+1;
end
always @(negedge clk)if(pass2_tex_check)begin
    assert(tex_stream.req_head===pass2_tex_expected)
      else $fatal(1,"request prefetch/forwarding cycle mismatch");
    pass2_tex_check_count<=pass2_tex_check_count+1;
end
integer pass2_fd;
final begin
    pass2_fd=$fopen("ram-coverage.txt","w");
    $fwrite(pass2_fd,"checked %0d\nreads %0d\nwrites %0d\nahead %0d\nsimultaneous %0d\nfull %0d\nempty %0d\nwrap %0d\nhold %0d\n",pass2_checked,pass2_reads,pass2_writes,pass2_ahead,pass2_simultaneous,pass2_full,pass2_empty,pass2_wrap,pass2_hold);
    $fwrite(pass2_fd,"tex_push %0d\ntex_pop %0d\ntex_forward %0d\ntex_hold %0d\ntex_checks %0d\n",pass2_tex_push,pass2_tex_pop,pass2_tex_forward,pass2_tex_hold,pass2_tex_check_count);
    $fclose(pass2_fd);
end
'''
def main():
    start=time.time();out=HERE/'full-write-path-poison';out.mkdir(exist_ok=False)
    before=json.loads((BASE/'input-pins.json').read_text());assert inventory(BASE/'inputs')==before
    parent=json.loads((BASE/'receipt.json').read_text());assert parent['passed']
    candidate=HERE/'gpu_core.v';assert sha(candidate)==CANDIDATE_SHA
    old=(DEPLOYED/'src/fpga/common/os30/gpu_core.v').read_text();new=candidate.read_text()
    marker='    (* ramstyle = "MLAB, no_rw_check" *) reg [REQ_W-1:0] requests [0:3];'
    assert old.count(marker)==2 and old.replace(marker,marker.replace('MLAB','M10K'),1)==new
    assert sha(DEPLOYED/'src/fpga/common/os30/gpu_core.v')==before['gpu_core.v']
    # Every instantiated production module must be the deployed source; generic
    # cache/source-name ambiguity is forbidden by this explicit path table.
    source_paths={
      'gpu_core.v':'src/fpga/common/os30/gpu_core.v',
      'gpu_color_depth_cache.sv':'src/fpga/common/os30/gpu_color_depth_cache.sv',
      'gpu_geometry_worker.v':'src/fpga/common/gpu_geometry_worker.v',
      'gpu_edge_walker.v':'src/fpga/common/gpu_edge_walker.v',
      'gpu_tex_cache.v':'src/fpga/common/os30/gpu_tex_cache.v',
      'axi_sdram_arbiter.v':'src/fpga/common/axi_sdram_arbiter.v',
      'axi_sdram_slave.v':'src/fpga/common/axi_sdram_slave.v',
      'sync_fifo.v':'src/fpga/common/sync_fifo.v',
    }
    for name,rel in source_paths.items():assert sha(DEPLOYED/rel)==before[name],rel
    shutil.copytree(BASE/'inputs',out/'inputs')
    assert new.count('\nendmodule')==1
    poisoned=new.replace('req_raw <= requests[req_next];','req_raw <= (req_push && req_wr==req_next) ? ~{fp_tex_addr_full,sp_truecolor} : requests[req_next];')
    assert poisoned!=new
    (out/'inputs/gpu_core.v').write_text(poisoned.replace('\nendmodule',OBSERVER+'\nendmodule'))
    cpp=out/'inputs/tb_gpu_wrpath_main.cpp';ct=cpp.read_text();mark='    delete tb;\n    return total_diff ? 1 : 0;';assert ct.count(mark)==1
    cpp.write_text(ct.replace(mark,'    tb->final();\n'+mark))
    after=inventory(out/'inputs');assert {k for k in before if before[k]!=after[k]}=={'gpu_core.v','tb_gpu_wrpath_main.cpp'}
    save(out/'input-pins.json',after)
    cmd=[x.replace(str(BASE),str(out))for x in json.loads((BASE/'build-command.json').read_text())]
    save(out/'build-command.json',cmd)
    with(out/'build.log').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
    with(out/'run.log').open('w')as log:subprocess.run([str(out/'obj/Vtb_gpu_wrpath')],cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True)
    assert (out/'run.log').read_bytes()==(BASE/'run.log').read_bytes()
    names=['quiet-color.bin','quiet-depth.bin','contended-color.bin','contended-depth.bin','all-word-writes.bin']
    for name in names:assert (out/name).read_bytes()==(BASE/name).read_bytes(),name
    coverage={k:int(v)for k,v in [s.split()for s in (out/'ram-coverage.txt').read_text().splitlines()]}
    for name in ['checked','reads','writes','ahead','simultaneous','full','empty','wrap','hold','tex_push','tex_pop','tex_forward','tex_checks']:assert coverage[name]>0,name
    assert inventory(out/'inputs')==after and inventory(BASE/'inputs')==before
    r=dict(passed=True,candidate_sha256=CANDIDATE_SHA,parent_receipt_sha256=sha(BASE/'receipt.json'),
      exact_active_deployed_sources=source_paths,source_unchanged=True,attribute_only=True,
      exact_complete_run_transcript=True,exact_all_color_depth_bytes=True,exact_all_timed_word_writes=True,
      color_depth_bytes_compared=sum((out/n).stat().st_size for n in names[:4]),
      physical_word_write_records=(out/names[-1]).stat().st_size//18,cycles=1791183,
      ram_coverage=coverage,assertions_passed=['occupancy range','pointer/count modular relation','read occupied head','write free tail','no observed same-address simultaneous read/write','same-edge registered AW capture and hold','texture prefetch and same-address forwarding exact including deliberately poisoned collision read data'],
      dumps_sha256={n:sha(out/n)for n in names},warning=parent['warning'],scope=__doc__,limitations=parent['limitations']+['Vendor memory inference/physical RAM timing require separate Quartus evidence. RTL simulation ignores ramstyle. Raw collision reads are deliberately inverted; explicit forwarding must mask them. This fixture exercises requests but has zero texture request backpressure cycles.'],
      recipe_sha256=sha(Path(__file__)),elapsed_seconds=time.time()-start,quartus_launched=False,deployed=False)
    save(out/'receipt.json',r);print(json.dumps(r,indent=2),flush=True)
if __name__=='__main__':main()
