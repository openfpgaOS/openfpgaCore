module request_parent(input clk,input[1:0]req_rd,req_wr,input req_pop,req_push,
input[25:0]fp_tex_addr_full,input sp_truecolor,output[26:0]head);
localparam REQ_W=27;
    (* ramstyle = "MLAB, no_rw_check" *) reg [REQ_W-1:0] requests [0:3];
    wire [1:0] req_next = req_rd + {1'b0, req_pop};
    reg [REQ_W-1:0] req_raw, req_forward;
reg req_forward_valid;
always @(posedge clk) begin
        req_raw <= requests[req_next];
        req_forward <= {fp_tex_addr_full, sp_truecolor};
        req_forward_valid <= req_push && (req_wr == req_next);
    if(req_push) begin
            requests[req_wr] <= {fp_tex_addr_full, sp_truecolor};
    end
end
    wire [REQ_W-1:0] req_head = req_forward_valid ? req_forward : req_raw;
assign head=req_head;
endmodule

module request_candidate(input clk,input[1:0]req_rd,req_wr,input req_pop,req_push,
input[25:0]fp_tex_addr_full,input sp_truecolor,output[26:0]head);
localparam REQ_W=27;
    (* ramstyle = "M10K, no_rw_check" *) reg [REQ_W-1:0] requests [0:3];
    wire [1:0] req_next = req_rd + {1'b0, req_pop};
    reg [REQ_W-1:0] req_raw, req_forward;
reg req_forward_valid;
always @(posedge clk) begin
        req_raw <= requests[req_next];
        req_forward <= {fp_tex_addr_full, sp_truecolor};
        req_forward_valid <= req_push && (req_wr == req_next);
    if(req_push) begin
            requests[req_wr] <= {fp_tex_addr_full, sp_truecolor};
    end
end
    wire [REQ_W-1:0] req_head = req_forward_valid ? req_forward : req_raw;
assign head=req_head;
endmodule
module request_compare(input clk,
input[1:0]parent_rd,parent_wr,candidate_rd,candidate_wr,
input parent_pop,parent_push,candidate_pop,candidate_push,
input[25:0]parent_addr,candidate_addr,input parent_wide,candidate_wide,
output[26:0]parent_head,candidate_head);
request_parent parent(clk,parent_rd,parent_wr,parent_pop,parent_push,parent_addr,parent_wide,parent_head);
request_candidate candidate(clk,candidate_rd,candidate_wr,candidate_pop,candidate_push,candidate_addr,candidate_wide,candidate_head);
endmodule
