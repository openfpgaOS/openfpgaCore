Selected GPU texture-request memory migration
============================================

Candidate GPU: dc1298bb26c62dc682496b276c405f06069389a1d6468e86c4bc89103ac78656
Combined source: f3685d901a8688ff9c62cb9e4259a61d04e45fe646532ebc6c744e617df81b1b
Parent deployed source: 9a4e8b063a2ac21c59d7dbfc47335155760666d22b10095dda27559573329a87

Only the requests array in the active INCLUDE_TEX_QUEUE_RAM/MLAB branch moves
from MLAB to M10K. Its four27-bit entries already use unconditional registered
next-head reads and explicit same-address forwarding. The framebuffer queue,
results queue and metadata queue retain their original implementation. No
state, depth, credit limit, payload, read/write enable or cycle changes.
CPU ISA,32-voice audio, Dock and resolution remain intact. The exact one-line
attribute change is in source.patch; all functional RTL is byte-identical.

This replacement is better than moving framebuffer addresses to M10K because
its existing prefetch/forwarding needs no new conditional-hold wrapper. The
single comparative component synthesis maps parent storage+forwarding to
30ALUT/55FF and candidate to30ALUT/28FF plus one4x27 M10K. The full combined
root map (this GPU change plus audio position readback and SDRAM wbuf) gives:

  Logic ALUTs       26,573 ->26,541   (-32)
  Memory ALUTs         314 ->   229   (-85)
  Logic registers   23,955 ->23,866   (-89)
  Estimated ALMs    17,936 ->17,854   (-82)

These are synthesis results, not physical occupied LABs or timing results.
The full30-seed physical sweep uses this frozen combined source. No new FPS
or Fmax gain is claimed until measured. The earlier framebuffer-address trial
remains frozen separately and is superseded; its four fits were interrupted
by the root before choosing this source.

Qualification PASS:
- Deployed archive and all128 frozen files match the published parent pins.
  Only the first request array ramstyle changes;13,824 bit-level forwarding
  cases show that arbitrary mixed-port collision data is masked.
- The exact extracted request/results/metadata schedule runs200,000 lockstep
  cycles. Visible flags, payloads and all queue state are exact with candidate
  raw collision reads deliberately inverted. Coverage includes4,249 collision
  forwards,56,161 request stalls,79,711 result stalls,75,478 full-request cycles,
  19,217 full-result cycles,13,090 wraps and30 resets.
- Full GPU/cache/arbiter/slave write-path runs1,791,183 cycles; all614,400
  color/depth bytes and19,442 timed physical word writes match the control.
  It exercises132,264 texture pushes/pops and7,546 poisoned collision forwards.
  This fixture has zero texture-request backpressure; the extracted queue
  and actual game-frame tests supply additional coverage.
- All eight native6 game frames in paced/unpaced modes preserve full output,
  every recorded counter/cycle and fence trace exactly (16 real GPU replays).
- The actual root map infers one4x27 M10K, ADDRESS_REG_B=CLOCK0 and
  OUTDATA_REG_B=UNREGISTERED. Primitive read-clock pin1 and write-clock pin0
  both connect to the same clock0 input; read-enable is tied high. Mixed-port
  DONT_CARE is safe because the original registered forwarding masks every
  same-address write. There is no new read stage or clock domain.

Limits: RTL simulation ignores ramstyle; inference parameters provide the
separate memory-implementation gate. No post-fit gate-level simulation is
claimed. The write-path fixture uses synthetic other-master traffic and a
split-DQ test SDRAM controller, not Pocket PHY; its inherited1701/1700 refresh
warning is identical to control. Game replays do not predict real-device FPS.

Frozen proof files/recipes:
  source.patch, verify_source.py, source-qualification.json
  prepare.py, preparation.json, request_compare.v, request.qsf
  output_files/request.map.rpt (comparative component map)
  run_queue.py, queue-lockstep/{parent.sv,candidate.sv,tb.sv,receipt.json,run.log}
  run_writepath.py, full-write-path-poison/{receipt.json,input-pins.json,run.log}
  full-gpu-v1/receipt.json (8 frames x2 modes, full source/vector references)
  check_inference.py, inference-qualification.json (root actual map binding)
  ../../audit/texture-requests-m10k-independent-review.json
  qualification.json (aggregate evidence pins)

No proprietary vendor simulation source or compiled object tree is needed in
an exported proof bundle. Large game-frame captures remain external referenced
inputs; a receipt-only bundle must state that limitation.
