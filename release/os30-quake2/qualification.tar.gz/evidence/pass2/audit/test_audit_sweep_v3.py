#!/usr/bin/env python3
import copy
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest

sys.dont_write_bytecode = True
import audit_sweep_v3 as audit


def fixture():
    rows = []
    for label, (owner, name, depth, width) in audit.RAMS.items():
        rows.append(['core_top:ic|' + owner + '|altsyncram:' + name + '_rtl_0|ram',
                     'M10K block', 'Simple Dual Port', 'Single Clock', str(depth), str(width),
                     str(depth), str(width), 'yes', 'no', 'yes', 'no', str(depth * width),
                     str(depth), str(width), str(depth), str(width), str(depth * width),
                     '1', '0', 'None', 'M10K_X10_Y10_N0'])
    return rows


def report(rows):
    return '\n'.join('; ' + ' ; '.join(row) + ' ;' for row in rows)


class PhysicalMemory(unittest.TestCase):
    def test_current_exact_profile_and_review_are_accepted(self):
        p = audit.read_profile(audit.HERE / 'profile-fbwq-pos-wbuf.json')
        self.assertEqual(p['source_sha256'], '7b67e73e6626be8c733d5ade5ba507b5890e4df082c2b846bb01206e53b4cf53')

    def test_two_source_profiles_cannot_be_crossed(self):
        pairs = [('full-sweep', 'profile-fbwq-pos-wbuf.json'),
                 ('full-sweep-texture', 'profile-texture-pos-wbuf.json')]
        profiles = [audit.read_profile(audit.HERE / name) for _, name in pairs]
        for i, (name, _) in enumerate(pairs):
            trial = audit.HERE.parent / name
            sw = audit.driver(trial); manifest = sw.verify(trial)
            audit.check_source(sw, trial, manifest, profiles[i])
            with self.assertRaises(ValueError):
                audit.check_source(sw, trial, manifest, profiles[1 - i])

    def test_wrong_source_recipe_changed_input_or_missing_review_rejects(self):
        original = json.loads((audit.HERE / 'profile-fbwq-pos-wbuf.json').read_text())
        cases = []
        for key in ('source_sha256', 'baseline_sha256'):
            p = copy.deepcopy(original); p[key] = '0' * 64; cases.append(p)
        p = copy.deepcopy(original); p['recipe_sha256']['results.py'] = '0' * 64; cases.append(p)
        p = copy.deepcopy(original); p['qualified_changed_inputs']['src/fpga/targets/pocket/os30/io_sdram.v'] = '0' * 64; cases.append(p)
        p = copy.deepcopy(original); p['source_review']['sha256'] = '0' * 64; cases.append(p)
        p = copy.deepcopy(original); p['ram_expectations']['gpu_fbwq_addr'][0] = 'cpu_system:cpu'; cases.append(p)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            review = original['source_review']['path']
            (root / review).write_bytes((audit.HERE / review).read_bytes())
            for p in cases:
                (root / 'profile.json').write_text(json.dumps(p))
                with self.subTest(profile=p), self.assertRaises(ValueError):
                    audit.read_profile(root / 'profile.json')

    def test_three_exact_registered_memories(self):
        result = audit.ram_placements(report(fixture()))
        self.assertEqual(set(result), set(audit.RAMS))
        self.assertTrue(all(r['physical_blocks'] == 1 and r['mlabs'] == 0 for r in result.values()))

    def test_duplicate_missing_or_wrong_owner_reject(self):
        rows = fixture()
        for changed in [rows[:-1], rows + [rows[0]], [list(rows[0]), *rows[1:]]]:
            if len(changed) == 3:
                changed[0][0] = changed[0][0].replace('gpu_core:gpu', 'unrelated:gpu')
            with self.assertRaises(ValueError):
                audit.ram_placements(report(changed))

    def test_type_depth_width_register_and_location_are_required(self):
        for index, value in [(1, 'MLAB'), (4, '8'), (5, '12'), (6, '8'), (7, '12'),
                             (10, 'no'), (11, 'yes'), (18, '2'), (19, '1'), (21, 'LAB_X10_Y10_N0')]:
            rows = fixture(); rows[0][index] = value
            with self.subTest(index=index), self.assertRaises(ValueError):
                audit.ram_placements(report(rows))

    def test_real_deployed_mlab_report_cannot_qualify_the_new_mapping(self):
        archive = audit.HERE.parents[1] / 'timing-next/physical-corrected-cache-mixer/seeds/seed_01/attempt_01/quartus-reports.tar.gz'
        with tarfile.open(archive) as tar:
            text = tar.extractfile('src/fpga/targets/pocket/output_files/ap_core.fit.rpt').read().decode(errors='replace')
        with self.assertRaises(ValueError):
            audit.ram_placements(text)

    def test_actual_quartus_m10k_type_and_register_semantics(self):
        archive = audit.HERE.parents[1] / 'timing-next/physical-corrected-cache-mixer/seeds/seed_01/attempt_01/quartus-reports.tar.gz'
        with tarfile.open(archive) as tar:
            text = tar.extractfile('src/fpga/targets/pocket/output_files/ap_core.fit.rpt').read().decode(errors='replace')
        # Three existing physical M10Ks from the real25.1 fitter report validate
        # report parsing independently of the new candidate's source hints.
        expectations = {
            'sample_data': ('audio_sample_cache:mixer_sample_cache', 'data_mem_rtl_', 256, 32),
            'sample_tags': ('audio_sample_cache:mixer_sample_cache', 'tag_mem_rtl_', 32, 27),
            'uart': ('axi_periph_slave:periph', 'uart_rx_fifo_rtl_', 1024, 8),
        }
        result = audit.ram_placements(text, expectations)
        self.assertEqual(set(result), set(expectations))
        self.assertTrue(all(row['memory_type'] == 'M10K block'
                            and row['port_b_address_registered']
                            and not row['port_b_output_registered'] for row in result.values()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
