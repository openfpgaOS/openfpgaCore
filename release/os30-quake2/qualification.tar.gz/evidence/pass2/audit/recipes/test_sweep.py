#!/usr/bin/env python3
"""Offline failure fixtures and fake-Quartus map-once/resume integration."""
import contextlib
import csv
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import results
import sweep

MAIN = 'ic|mp_ram|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk'


def timing(root, fmax=95.0, setup=-0.526, hold=0.1, other=1.0, cross=0.3, inputs=0.4):
    root.mkdir(parents=True, exist_ok=True)
    conditions = sorted(results.CORNERS)
    rows = [[m, t, c, setup if c == 'setup' else hold if c == 'hold' else 0.2]
            for m, t in conditions for c in results.CHECKS]
    for name, headers, data in [
        ('summary.tsv', ['model','temperature','check','slack'], rows),
        ('conditions.tsv', ['model','temperature'], conditions),
        ('clocks.tsv', ['model','temperature','check','clock','slack'],
         [[m,t,c,clk,setup if c == 'setup' and clk == MAIN else other if c == 'setup' else hold if c == 'hold' else 0.2]
          for m,t in conditions for c in results.CHECKS[:4] for clk in [MAIN,'clk_74a']]),
        ('cross_setup.tsv', ['model','temperature','source_kind','source','target','slack','used_slack'],
         [[m,t,'clock',source,target,cross,cross] for m,t in conditions
          for source,target in [(MAIN,'clk_74a'),('clk_74a',MAIN)]] +
         [[m,t,'input','all_input_ports',target,inputs,inputs] for m,t in conditions
          for target in [MAIN,'clk_74a']]),
        ('ddio_checks.tsv', ['model','temperature','check','slack'],
         [[m,t,c,'no_paths' if c=='high_output' else 2.0]
          for m,t in conditions for c in ('high_output','low_input','low_output')])]:
        with (root / name).open('w') as stream:
            writer = csv.writer(stream, delimiter='\t'); writer.writerow(headers); writer.writerows(data)
    with (root/'ddio_proof.tsv').open('w')as stream:
        writer=csv.writer(stream,delimiter='\t');writer.writerow(['role','bit','name','type','location','fanout_count','fanouts'])
        for role,signal in [('high','dataout_h'),('low','dataout_l'),('falling','ddio_ina')]:
            for bit in range(16):
                name=f'core_top:ic|io_sdram:isr0|altddio_in:u_dq_ddio_in|ddio_in_test:auto_generated|{signal}[{bit}]'+('~DFFLO'if role=='falling'else'')
                fans=','.join(f'core_top:ic|io_sdram:isr0|{n}[{b}]' for n in ('word_q','burst_data')for b in (bit,bit+16))if role=='low'else''
                writer.writerow([role,bit,name,'reg','DDIOINCELL_X42_Y45_N31',4 if role=='low'else 0,fans])
    for m,t in conditions:
        (root / f'{m}_{t}_fmax.rpt').write_text(f'; {fmax:.2f} MHz ; {fmax:.2f} MHz ; {MAIN} ; ;\n; 120.0 MHz ; 120.0 MHz ; clk_74a ; ;\n')


def fit(root):
    output = root / 'output_files'; output.mkdir(parents=True, exist_ok=True)
    (output / 'ap_core.fit.summary').write_text('Fitter Status : Successful\nLogic utilization (in ALMs) : 17,000 / 18,480\nTotal RAM Blocks : 295 / 308\nTotal DSP Blocks : 36 / 66\n')
    (output / 'ap_core.fit.rpt').write_text('; Total LABs:  partially or completely used ; 1,800 / 1,848 ;\n')


class Parsing(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name); fit(self.root); timing(self.root/'timing')

    def parse(self):
        return results.parse(self.root, self.root/'timing')

    def change(self, check, value):
        p=self.root/'timing/summary.tsv';rows=results.table(p)
        rows[0 if check=='setup' else next(i for i,r in enumerate(rows)if r['check']==check)]['slack']=value
        with p.open('w')as f:
            writer=csv.DictWriter(f,fieldnames=['model','temperature','check','slack'],delimiter='\t');writer.writeheader();writer.writerows(rows)

    def test_estimate_does_not_claim_100_closure(self):
        r=self.parse();self.assertTrue(r['eligible_above_90_mhz_estimate']);self.assertFalse(r['timing_closed_at_configured_100_mhz'])

    def test_100_closed(self):
        timing(self.root/'timing',fmax=101,setup=0.1)
        self.assertTrue(self.parse()['timing_closed_at_configured_100_mhz'])

    def test_negative_nonsetup_rejects_each_type(self):
        for check in results.CHECKS[1:]:
            timing(self.root/'timing');self.change(check,'-0.001');self.assertFalse(self.parse()['eligible_above_90_mhz_estimate'])

    def test_nonmain_setup_negative_rejects(self):
        timing(self.root/'timing',other=-0.001);self.assertFalse(self.parse()['eligible_above_90_mhz_estimate'])

    def test_cross_clock_into_main_negative_rejects(self):
        timing(self.root/'timing',fmax=101,setup=0.1)
        self.edit_crossing('clock',MAIN,slack='-0.001',used_slack='-0.001')
        r=self.parse();self.assertFalse(r['cross_clock_setup_clean'])
        self.assertFalse(r['eligible_above_90_mhz_estimate'])
        self.assertFalse(r['timing_closed_at_configured_100_mhz'])

    def test_input_into_main_negative_rejects(self):
        timing(self.root/'timing',fmax=101,setup=0.1)
        self.edit_crossing('input',MAIN,slack='-0.001',used_slack='-0.001')
        r=self.parse();self.assertFalse(r['input_setup_clean'])
        self.assertFalse(r['eligible_above_90_mhz_estimate'])
        self.assertFalse(r['timing_closed_at_configured_100_mhz'])

    def test_crossing_completeness_and_nonfinite_rejected(self):
        p=self.root/'timing/cross_setup.tsv'
        for mode in ('missing','duplicate','badkind','nan'):
            timing(self.root/'timing');rows=results.table(p)
            if mode=='missing':rows.pop()
            elif mode=='duplicate':rows[-1]=rows[0]
            elif mode=='badkind':rows[0]['source_kind']='ignored'
            else:rows[0]['slack']='nan'
            with p.open('w')as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
            with self.assertRaises(ValueError):self.parse()

    def test_absent_crossing_paths_explicitly_recorded(self):
        timing(self.root/'timing',cross='no_paths',inputs='no_paths')
        r=self.parse();self.assertTrue(r['eligible_above_90_mhz_estimate'])
        self.assertIsNone(r['worst_cross_clock_setup_ns']);self.assertIsNone(r['worst_input_setup_ns'])

    def edit_crossing(self,kind,target,**changes):
        p=self.root/'timing/cross_setup.tsv';rows=results.table(p)
        next(r for r in rows if r['source_kind']==kind and r['target']==target).update(changes)
        with p.open('w')as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)

    def test_only_proved_unused_ddio_input_can_be_classified(self):
        self.edit_crossing('input',MAIN,slack='-0.842',used_slack='0.400')
        r=self.parse();self.assertTrue(r['eligible_above_90_mhz_estimate'])
        self.assertEqual(r['worst_input_setup_ns'],-0.842)
        self.assertEqual(r['worst_used_input_setup_ns'],0.4)
        self.assertEqual(r['unused_ddio_endpoint_proof']['excluded_unused_high_endpoint_count'],16)

    def test_ddio_missing_or_changed_connectivity_rejects(self):
        p=self.root/'timing/ddio_proof.tsv'
        for mode in ('missing','high_used','low_changed'):
            timing(self.root/'timing');rows=results.table(p)
            if mode=='missing':rows.pop()
            else:
                row=next(r for r in rows if r['role']==('high'if mode=='high_used'else'low'))
                row['fanout_count']='1';row['fanouts']='unexpected_functional_consumer'
            with p.open('w')as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
            with self.assertRaises(ValueError):self.parse()

    def test_used_ddio_input_negative_still_rejects(self):
        p=self.root/'timing/ddio_checks.tsv';rows=results.table(p)
        next(r for r in rows if r['check']=='low_input')['slack']='-0.001'
        with p.open('w')as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
        self.assertFalse(self.parse()['eligible_above_90_mhz_estimate'])

    def test_no_other_crossing_or_input_waiver(self):
        for kind,target in [('clock',MAIN),('input','clk_74a')]:
            timing(self.root/'timing');self.edit_crossing(kind,target,slack='-0.8',used_slack='0.3')
            with self.assertRaises(ValueError):self.parse()

    def test_no_dropped_populated_crossing(self):
        self.edit_crossing('input',MAIN,slack='-0.8',used_slack='no_paths')
        with self.assertRaises(ValueError):self.parse()

    def test_strictly_greater_than_90(self):
        timing(self.root/'timing',fmax=90);self.assertFalse(self.parse()['eligible_above_90_mhz_estimate'])

    def test_missing_corner_and_duplicate_are_rejected(self):
        p=self.root/'timing/summary.tsv';lines=p.read_text().splitlines();p.write_text('\n'.join(lines[:-1]+[lines[1]])+'\n')
        with self.assertRaises(ValueError):self.parse()

    def test_nan_inf_and_required_no_paths_rejected(self):
        for value in ['nan','inf','-inf','no_paths']:
            timing(self.root/'timing');self.change('setup',value)
            with self.assertRaises(ValueError):self.parse()

    def test_optional_reset_no_paths(self):
        self.change('recovery','no_paths');self.change('removal','no_paths');self.assertTrue(self.parse()['eligible_above_90_mhz_estimate'])

    def test_fmax_missing_fast_corner_rejected(self):
        (self.root/'timing/fast_85_fmax.rpt').unlink()
        with self.assertRaises(FileNotFoundError):self.parse()

    def test_missing_physical_lab_rejected(self):
        (self.root/'output_files/ap_core.fit.rpt').write_text('no occupancy\n')
        with self.assertRaises(ValueError):self.parse()

    def test_no_selection_before_all_seeds(self):
        with self.assertRaises(ValueError):results.select([])

    def test_100_closed_preferred_and_high_fmax_bad_hold_rejected(self):
        rows=[]
        for seed in range(1,31):
            timing(self.root/'timing',fmax=110 if seed==1 else 101 if seed==2 else 95,
                   setup=0.1 if seed in [1,2] else-0.526,hold=-0.01 if seed==1 else 0.1)
            rows.append(dict(seed=seed,state='complete',valid_reports=True,**self.parse()))
        self.assertEqual(results.select(rows)['selected_seed'],2)


class SynthesisPolicy(unittest.TestCase):
    BASE = ('set_global_assignment -name DEVICE 5CEBA4F23C8\n'
            'set_global_assignment -name OPTIMIZATION_TECHNIQUE SPEED\n'
            'set_global_assignment -name SDC_FILE core_constraints.sdc\n'
            'set_instance_assignment -name OPTIMIZATION_TECHNIQUE SPEED -to ic|cpu|cpu\n')

    def test_area_is_allowed_and_last_assignment_is_recorded(self):
        candidate = self.BASE + 'set_global_assignment -name OPTIMIZATION_TECHNIQUE AREA\n'
        self.assertEqual(sweep.protected_qsf(candidate), sweep.protected_qsf(self.BASE))
        self.assertEqual(sweep.optimization_technique(candidate),
                         dict(effective='AREA', assignments=['SPEED', 'AREA']))
        for value in ('AREA', 'SPEED', 'BALANCED'):
            self.assertEqual(sweep.optimization_technique(
                'set_global_assignment -name OPTIMIZATION_TECHNIQUE '+value)['effective'], value)

    def test_invalid_technique_and_tcl_suffix_are_rejected(self):
        for value in ('FAST', 'AREA; source evil.tcl', 'AREA -entity cpu', '"AREA"', ''):
            with self.assertRaises(ValueError):
                sweep.protected_qsf(self.BASE+'set_global_assignment -name OPTIMIZATION_TECHNIQUE '+value)

    def test_cpu_override_and_clock_constraints_stay_protected(self):
        for candidate in (self.BASE.replace('core_constraints.sdc', 'weakened.sdc'),
                          self.BASE.replace('SPEED -to ic|cpu|cpu', 'AREA -to ic|cpu|cpu')):
            self.assertNotEqual(sweep.protected_qsf(candidate), sweep.protected_qsf(self.BASE))

    def test_reviewed_global_physical_choices_and_history(self):
        text=self.BASE+'set_global_assignment -name PHYSICAL_SYNTHESIS_COMBO_LOGIC OFF\nset_global_assignment -name PHYSICAL_SYNTHESIS_EFFORT NORMAL\n'
        changed=text+'set_global_assignment -name PHYSICAL_SYNTHESIS_COMBO_LOGIC ON\nset_global_assignment -name PHYSICAL_SYNTHESIS_EFFORT FAST\n'
        self.assertEqual(sweep.protected_qsf(text),sweep.protected_qsf(changed))
        self.assertEqual(sweep.physical_synthesis(changed),{
            'PHYSICAL_SYNTHESIS_COMBO_LOGIC':dict(effective='ON',assignments=['OFF','ON']),
            'PHYSICAL_SYNTHESIS_EFFORT':dict(effective='FAST',assignments=['NORMAL','FAST'])})
        for value in ('NORMAL','FAST','EXTRA'):
            self.assertEqual(sweep.physical_synthesis('set_global_assignment -name PHYSICAL_SYNTHESIS_EFFORT '+value)['PHYSICAL_SYNTHESIS_EFFORT']['effective'],value)

    def test_invalid_physical_choice_or_tcl_suffix_rejected(self):
        for name,values in [('PHYSICAL_SYNTHESIS_COMBO_LOGIC',('TRUE','OFF; source evil.tcl','ON -to cpu','"ON"')),
                            ('PHYSICAL_SYNTHESIS_EFFORT',('HIGH','EXTRA; source evil.tcl','FAST -entity cpu','"FAST"'))]:
            for value in values:
                with self.assertRaises(ValueError):sweep.protected_qsf(self.BASE+'set_global_assignment -name '+name+' '+value)

    def test_physical_instance_and_retiming_stay_protected(self):
        for line in ('set_instance_assignment -name PHYSICAL_SYNTHESIS_EFFORT EXTRA -to ic|cpu|cpu\n',
                     'set_global_assignment -name PHYSICAL_SYNTHESIS_REGISTER_RETIMING ON\n',
                     'set_global_assignment -name PHYSICAL_SYNTHESIS_REGISTER_DUPLICATION OFF\n'):
            self.assertNotEqual(sweep.protected_qsf(self.BASE+line),sweep.protected_qsf(self.BASE))

    def test_exact_cpu_combo_scope_quoting_and_history(self):
        lines=['set_instance_assignment -name PHYSICAL_SYNTHESIS_COMBO_LOGIC ON -to ic|cpu|cpu',
               '  set_instance_assignment\t-name "PHYSICAL_SYNTHESIS_COMBO_LOGIC"  "ON"\t-to "ic|cpu|cpu"  ',
               'set_instance_assignment -name {PHYSICAL_SYNTHESIS_COMBO_LOGIC} {ON} -to {ic|cpu|cpu}']
        text=self.BASE+'\n'.join(lines)+'\n'
        self.assertEqual(sweep.protected_qsf(text),sweep.protected_qsf(self.BASE))
        self.assertEqual(sweep.cpu_combo_scope(text),dict(present=True,target='ic|cpu|cpu',effective='ON',
                         assignments=[dict(target='ic|cpu|cpu',value='ON')]*3))

    def test_cpu_combo_scope_other_targets_values_suffixes_rejected(self):
        for value,target in [('OFF','ic|cpu|cpu'),('ON','ic|cpu|*'),('ON','ic|gpu'),('ON','ic|cpu'),
                             ('ON','ic|cpu|cpu; source evil.tcl'),('ON','ic|cpu|cpu -entity VexiiRiscv')]:
            with self.assertRaises(ValueError):
                sweep.protected_qsf(self.BASE+f'set_instance_assignment -name PHYSICAL_SYNTHESIS_COMBO_LOGIC {value} -to {target}\n')

    def test_cpu_scope_does_not_allow_other_instance_options(self):
        for name,value in [('PHYSICAL_SYNTHESIS_REGISTER_DUPLICATION','OFF'),('PHYSICAL_SYNTHESIS_REGISTER_RETIMING','ON'),
                           ('OPTIMIZATION_TECHNIQUE','AREA')]:
            self.assertNotEqual(sweep.protected_qsf(self.BASE+f'set_instance_assignment -name {name} {value} -to ic|cpu|cpu\n'),sweep.protected_qsf(self.BASE))


class SdramStoragePolicy(unittest.TestCase):
    LINE = 'set_instance_assignment -name RAMSTYLE_ATTRIBUTE MLAB -to *sdram_axi_slave|wbuf*'
    BASE = SynthesisPolicy.BASE + LINE + '\n'

    def test_only_exact_instance_storage_value_changes(self):
        for value in ('MLAB', 'M10K'):
            for line in (self.LINE.replace('MLAB', value),
                         f'  set_instance_assignment\t-name "RAMSTYLE_ATTRIBUTE" "{value}" -to "*sdram_axi_slave|wbuf*"  ',
                         'set_instance_assignment -name {RAMSTYLE_ATTRIBUTE} {' + value + '} -to {*sdram_axi_slave|wbuf*}'):
                self.assertEqual(sweep.protected_qsf(self.BASE), sweep.protected_qsf(SynthesisPolicy.BASE + line + '\n'))
                self.assertEqual(sweep.sdram_wbuf_storage(line), dict(present=True,
                    target='*sdram_axi_slave|wbuf*', effective=value,
                    assignments=[dict(target='*sdram_axi_slave|wbuf*', value=value)]))

    def test_bad_value_suffix_or_scope_is_rejected(self):
        for value in ('AUTO', 'M20K', '', 'MLAB; source evil.tcl', 'M10K -entity cpu'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                sweep.protected_qsf(self.BASE.replace('RAMSTYLE_ATTRIBUTE MLAB', 'RAMSTYLE_ATTRIBUTE ' + value))
        for suffix in ('; source evil.tcl', ' -entity anything', ' -section_id anything'):
            with self.subTest(suffix=suffix), self.assertRaises(ValueError):
                sweep.protected_qsf(self.BASE.rstrip() + suffix)

    def test_no_assignment_removal_duplicate_or_other_target_change(self):
        self.assertNotEqual(sweep.protected_qsf(self.BASE), sweep.protected_qsf(SynthesisPolicy.BASE))
        self.assertNotEqual(sweep.protected_qsf(self.BASE), sweep.protected_qsf(self.BASE + self.LINE.replace('MLAB', 'M10K') + '\n'))
        for target in ('*sdram_axi_slave|other*', '*other|wbuf*', 'ic|gpu|anything'):
            changed = self.BASE.replace('*sdram_axi_slave|wbuf*', target).replace('RAMSTYLE_ATTRIBUTE MLAB', 'RAMSTYLE_ATTRIBUTE M10K')
            self.assertNotEqual(sweep.protected_qsf(self.BASE), sweep.protected_qsf(changed))
        unrelated = 'set_instance_assignment -name RAMSTYLE_ATTRIBUTE MLAB -to ic|cpu|ram\n'
        self.assertNotEqual(sweep.protected_qsf(self.BASE + unrelated),
                            sweep.protected_qsf(self.BASE + unrelated.replace('MLAB', 'M10K')))

    def test_cpu_clock_and_existing_physical_rules_are_still_protected(self):
        moved = self.BASE.replace('RAMSTYLE_ATTRIBUTE MLAB', 'RAMSTYLE_ATTRIBUTE M10K')
        for changed in (moved.replace('core_constraints.sdc', 'weak.sdc'),
                        moved.replace('SPEED -to ic|cpu|cpu', 'AREA -to ic|cpu|cpu'),
                        moved + 'set_global_assignment -name PHYSICAL_SYNTHESIS_REGISTER_RETIMING ON\n'):
            self.assertNotEqual(sweep.protected_qsf(self.BASE), sweep.protected_qsf(changed))


class Scheduling(unittest.TestCase):
    MEMORY = 20 * 1024**3

    def test_limits_allow_four_by_four_and_reject_overcommit(self):
        for jobs in range(1, 5):
            for processors in range(1, 5):
                sweep.validate_resource_limits(jobs, processors)
        for jobs, processors in [(0, 4), (5, 4), (4, 0), (4, 5), (2, 16)]:
            with self.assertRaises(ValueError):
                sweep.validate_resource_limits(jobs, processors)

    def test_four_slot_admission_and_lower_requested_limit(self):
        for active in range(4):
            self.assertTrue(sweep.can_start_seed(4, active, self.MEMORY, [], []))
        self.assertFalse(sweep.can_start_seed(4, 4, self.MEMORY, [], []))
        self.assertFalse(sweep.can_start_seed(2, 2, self.MEMORY, [], []))

    def test_external_fit_accounting_does_not_double_count_owned_fits(self):
        # Three reservations include two running own fitters and one clone.
        self.assertTrue(sweep.can_start_seed(4, 3, self.MEMORY, [10, 11], [10, 11]))
        self.assertFalse(sweep.can_start_seed(4, 3, self.MEMORY, [10, 11, 20], [10, 11]))
        self.assertTrue(sweep.can_start_seed(4, 1, self.MEMORY, [10, 20, 21], [10]))
        self.assertFalse(sweep.can_start_seed(4, 2, self.MEMORY, [10, 20, 21], [10]))
        self.assertFalse(sweep.can_start_seed(4, 0, self.MEMORY, [20, 21, 22, 23], []))

    def test_memory_admission_boundary_is_preserved(self):
        self.assertFalse(sweep.can_start_seed(4, 0, self.MEMORY - 1, [], []))
        self.assertTrue(sweep.can_start_seed(4, 3, self.MEMORY, [], []))


class Integration(unittest.TestCase):
    def test_map_once_private_database_failed_attempt_and_resume(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);source=root/'source';source.mkdir();baseline=root/'baseline';baseline.mkdir()
            qsf='set_global_assignment -name DEVICE 5CEBA4F23C8\nset_global_assignment -name SEED 2\nset_global_assignment -name VERILOG_MACRO VEXII_CPU_OS30\nset_global_assignment -name VERILOG_FILE ../../vendor/vexriscv/VexiiRiscv/VexiiRiscv_os30.v\n'
            inputs={str(sweep.QSF):qsf,'src/fpga/targets/pocket/test.sdc':'create_clock -period 10 core\n',
                'src/fpga/targets/pocket/os30.seed':'2\n','src/fpga/targets/pocket/megafunctions/pll.v':'// protected PLL\n',
                'src/fpga/vendor/vexriscv/VexiiRiscv/VexiiRiscv_os30.v':'// protected CPU\n'}
            for name,data in inputs.items():p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
            sweep.save(baseline/'manifest.json',dict(source_sha256=sweep.inventory(source)))
            sweep.archive(baseline/'source.tar.gz',source,[source/name for name in inputs])
            with contextlib.redirect_stdout(io.StringIO()):sweep.prepare(source,root/'out',baseline/'manifest.json')
            out=root/'out';manifest=sweep.load(out/'manifest.json');quartus=root/'quartus';quartus.mkdir()
            self.assertEqual(manifest['synthesis_optimization_technique'],
                             dict(effective='BALANCED', assignments=[]))
            self.assertEqual(manifest['physical_synthesis'],{
                name:dict(effective=None,assignments=[])for name in ('PHYSICAL_SYNTHESIS_COMBO_LOGIC','PHYSICAL_SYNTHESIS_EFFORT')})
            self.assertEqual(manifest['cpu_combo_scope'],dict(present=False,target=None,effective=None,assignments=[]))
            self.assertEqual(manifest['sdram_write_buffer_storage'],dict(present=False,target=None,effective=None,assignments=[]))
            tampered=json.loads(json.dumps(manifest));tampered['physical_synthesis']['PHYSICAL_SYNTHESIS_EFFORT']['effective']='EXTRA'
            sweep.save(out/'manifest.json',tampered)
            with self.assertRaises(ValueError):sweep.verify(out)
            sweep.save(out/'manifest.json',manifest)
            tampered=json.loads(json.dumps(manifest));tampered['cpu_combo_scope']['present']=True
            sweep.save(out/'manifest.json',tampered)
            with self.assertRaises(ValueError):sweep.verify(out)
            sweep.save(out/'manifest.json',manifest)
            tampered=json.loads(json.dumps(manifest));tampered['sdram_write_buffer_storage']['effective']='M10K'
            sweep.save(out/'manifest.json',tampered)
            with self.assertRaises(ValueError):sweep.verify(out)
            sweep.save(out/'manifest.json',manifest)
            helper=Path(__file__).resolve()
            code=f'''#!/usr/bin/env python3
import sys,pathlib,json,re,os
sys.path.insert(0,{str(helper.parent)!r})
from test_sweep import timing,fit
p=pathlib.Path.cwd();name=pathlib.Path(sys.argv[0]).name
with pathlib.Path({str(root/'calls')!r}).open('a')as log:log.write(name+' '+str(p)+'\\n')
if name=='quartus_sh':print({sweep.VERSION!r});sys.exit(0)
if name=='quartus_map':
 (p/'db').mkdir();(p/'db/netlist.bin').write_bytes(b'pristine');sys.exit(0)
seed=int(re.search(r' -name SEED (\\d+)',(p/'ap_core.qsf').read_text()).group(1))
if name=='quartus_fit':
 assert (p/'db/netlist.bin').read_bytes()==b'pristine'
 (p/'db/netlist.bin').write_text(str(seed));fit(p)
 if seed==7:sys.exit(2)
elif name=='quartus_asm':
 (p/'output_files/ap_core.rbf').write_bytes(bytes([seed,127,128]));(p/'output_files/ap_core.sof').write_bytes(bytes([seed]))
elif name=='quartus_sta'and'-t'in sys.argv:
 dest=pathlib.Path(sys.argv[-1]);timing(dest,fmax=101 if seed==5 else 99 if seed==1 else 95,setup=0.1 if seed==5 else-0.526,hold=-0.1 if seed==1 else 0.1)
 if seed==8:(dest/'fast_0_fmax.rpt').unlink()
 if seed==9:sys.exit(2)
 if seed!=5:print('Whole-design timing failed; see '+str(dest))
 sys.exit(0 if seed==5 else 3)
'''
            for name in ['sh','map','fit','asm','sta']:
                p=quartus/('quartus_'+name);p.write_text(code);p.chmod(0o755)
            with patch.object(sweep,'resources_available',return_value=(64*1024**3,[])),contextlib.redirect_stdout(io.StringIO()):
                sweep.run(out,manifest['frozen_sha256'],quartus,4,4,False,False,False)
            configuration=sweep.load(out/'run-configuration.json')
            self.assertEqual(configuration['maximum_global_fit_processes'],4)
            self.assertEqual(configuration['maximum_processors_per_process'],4)
            self.assertEqual(configuration['minimum_available_memory_gib'],20)
            rows=sweep.load(out/'results.json');selected=sweep.load(out/'selection.json')
            self.assertEqual(len(rows),30);self.assertEqual(selected['selected_seed'],5)
            subprocess.run([sys.executable,str(out/'recipes/sweep.py'),'collect',str(out)],
                           stdout=subprocess.DEVNULL,check=True)
            self.assertFalse((out/'recipes/__pycache__').exists())
            self.assertFalse(rows[0]['eligible_above_90_mhz_estimate'])
            self.assertEqual(rows[6]['state'],'failed');self.assertFalse(rows[6]['valid_reports'])
            self.assertEqual(rows[7]['state'],'failed');self.assertFalse(rows[7]['valid_reports'])
            self.assertEqual(rows[8]['state'],'failed');self.assertFalse(rows[8]['valid_reports'])
            self.assertEqual((out/'work/master'/sweep.PROJECT/'db/netlist.bin').read_bytes(),b'pristine')
            self.assertEqual(sweep.inventory(source),manifest['source_sha256'])
            self.assertFalse(list((out/'work').glob('seed_*')))
            calls=(root/'calls').read_text();self.assertEqual(calls.count('quartus_map '),1);self.assertEqual(calls.count('quartus_fit '),30)
            with patch.object(sweep,'resources_available',return_value=(64*1024**3,[])),contextlib.redirect_stdout(io.StringIO()):
                sweep.run(out,manifest['frozen_sha256'],quartus,1,4,True,False,False)
            self.assertEqual((root/'calls').read_text().count('quartus_fit '),30)
            with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()):
                sweep.run(out,manifest['frozen_sha256'],quartus,1,8,True,False,False)
            artifact=out/'seeds/seed_05/attempt_01/os30.rbf_r'
            original=artifact.read_bytes();artifact.write_bytes(b'wrong')
            with self.assertRaises(ValueError):sweep.collect(out)
            artifact.write_bytes(original)
            for name in ['src/fpga/targets/pocket/test.sdc','src/fpga/targets/pocket/megafunctions/pll.v']:
                p=source/name;old=p.read_text();p.write_text(old+'changed')
                with self.assertRaises(ValueError):sweep.prepare(source,root/'bad',baseline/'manifest.json')
                p.write_text(old)
            (source/sweep.QSF).write_text(qsf.replace('5CEBA4F23C8','wrong-device'))
            with self.assertRaises(ValueError):sweep.prepare(source,root/'bad',baseline/'manifest.json')


if __name__=='__main__':unittest.main(verbosity=2)
