#!/usr/bin/env python3
"""Read-only, source-bound audit of pass2 OS30 reports; never starts Quartus."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import tarfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PINS = {
    'sweep.py': '04c5cb4ea77e6f3b455405e3bff71cd803345dcdfec47b7d02175def2e9c6a80',
    'results.py': '192828cad6b134c0f6cacfd484611e1ec9db5ab27cf379974bd737296d4f110b',
    'report_sweep_timing.tcl': '2c66004df7b54c2e62a0c47ae976cf7c61da684ec034a169cb077ca00cdca34e',
}
BASE_SOURCE = '9a4e8b063a2ac21c59d7dbfc47335155760666d22b10095dda27559573329a87'
RAMS = {
    'gpu_fbwq_addr': ('gpu_core:gpu', 'fbwq_addr', 16, 24),
    'audio_pos_latch': ('audio_mixer:audio_mixer_inst', 'pos_latch', 32, 22),
    'sdram_wbuf': ('axi_sdram_slave:sdram_axi_slave', 'wbuf_rtl_', 16, 36),
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def driver(trial):
    for name, digest in PINS.items():
        if sha(trial / 'recipes' / name) != digest:
            raise ValueError('Unexpected recipe: ' + name)
    for name in ('results', 'sweep'):
        spec = importlib.util.spec_from_file_location(name, trial / 'recipes' / (name + '.py'))
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules['sweep']


def read_profile(path):
    path = Path(path).resolve()
    profile = load(path)
    if profile['baseline_sha256'] != BASE_SOURCE or profile['recipe_sha256'] != PINS:
        raise ValueError('Profile baseline/recipes are not the reviewed pass2 inputs')
    if not re.fullmatch(r'[0-9a-f]{64}', profile['source_sha256']):
        raise ValueError('Profile requires an exact source fingerprint')
    expected = {'src/fpga/common/os30/gpu_core.v', 'src/fpga/common/os30/audio_mixer.v',
                'src/fpga/targets/pocket/ap_core.qsf'}
    if set(profile['qualified_changed_inputs']) != expected:
        raise ValueError('Profile may only change the three reviewed storage inputs')
    if any(not re.fullmatch(r'[0-9a-f]{64}', h) for h in profile['qualified_changed_inputs'].values()):
        raise ValueError('Profile requires exact changed-input hashes')
    entry = profile['source_review']; name = Path(entry['path'])
    if name.is_absolute() or '..' in name.parts or str(name) != entry['path']:
        raise ValueError('Invalid source-review path')
    review_path = path.parent / name
    if sha(review_path) != entry['sha256']:
        raise ValueError('Pinned independent source review changed')
    review = load(review_path)
    if (not review.get('passed') or review.get('frozen_sha256') != profile['source_sha256']
            or set(review.get('changed_source_files', [])) != expected
            or not review.get('all89_dock_video_target_inputs_unchanged')
            or not review.get('original_cpu_and_all_protected_clock_sdc_seed_inputs_unchanged')):
        raise ValueError('Independent source review does not qualify this profile')
    ram = profile['ram_expectations']
    if (ram.get('audio_pos_latch') != ['audio_mixer:audio_mixer_inst', 'pos_latch', 32, 22]
            or ram.get('sdram_wbuf') != ['axi_sdram_slave:sdram_axi_slave', 'wbuf_rtl_', 16, 36]
            or len(ram) != 3):
        raise ValueError('Expected unchanged audio/SDRAM storage plus one reviewed GPU RAM')
    for owner, name, depth, width in ram.values():
        if not owner or not name or type(depth) is not int or type(width) is not int or depth <= 0 or width <= 0:
            raise ValueError('Invalid exact RAM expectation')
    gpu = [value for label, value in ram.items() if label not in ('audio_pos_latch', 'sdram_wbuf')]
    if len(gpu) != 1 or gpu[0][0] != 'gpu_core:gpu':
        raise ValueError('Third RAM must belong to the reviewed GPU instance')
    return profile


def ram_placements(report, expectations=RAMS):
    """Parse actual Fitter RAM Summary rows, not source attributes or map hints."""
    rows = []
    for line in report.splitlines():
        cells = [s.strip() for s in line.split(';')[1:-1]]
        if len(cells) >= 22 and cells[1] in ('MLAB', 'M10K block'):
            rows.append(cells)
    result = {}
    for label, (owner, name, depth, width) in expectations.items():
        matches = [r for r in rows if owner in r[0] and name in r[0]]
        if len(matches) != 1:
            raise ValueError('Expected exactly one fitted RAM: ' + label)
        r = matches[0]
        if (r[1:4] != ['M10K block', 'Simple Dual Port', 'Single Clock']
                or list(map(int, r[4:8])) != [depth, width, depth, width]
                or r[10:12] != ['yes', 'no'] or int(r[18]) != 1 or int(r[19]) != 0
                or not re.search(r'\bM10K_X\d+_Y\d+_N\d+\b', r[21])):
            raise ValueError('Wrong physical RAM mapping/registered output: ' + label)
        result[label] = dict(instance=r[0], memory_type=r[1], mode=r[2], clocking=r[3],
                             port_a_depth=depth, port_a_width=width,
                             port_b_depth=int(r[6]), port_b_width=int(r[7]),
                             port_b_address_registered=True, port_b_output_registered=False, physical_blocks=int(r[18]),
                             mlabs=int(r[19]), locations=r[21], raw_cells=r)
    return result


def check_source(sw, trial, manifest, profile):
    if (manifest['frozen_sha256'] != profile['source_sha256']
            or sw.fingerprint(manifest['source_sha256']) != profile['source_sha256']
            or manifest['seeds'] != list(range(1, 31))
            or manifest['configured_mhz'] != 100 or manifest['saved_seed'] != 2):
        raise ValueError('Wrong frozen source/scope/configured clock')
    base_root = HERE.parents[1] / 'timing-next/physical-corrected-cache-mixer'
    base = load(base_root / 'manifest.json')
    old, current = base['source_sha256'], manifest['source_sha256']
    if sw.fingerprint(old) != BASE_SOURCE or len(current) != 128 or set(current) != set(old):
        raise ValueError('Source inventory/baseline mismatch')
    expected = {'src/fpga/common/os30/gpu_core.v', 'src/fpga/common/os30/audio_mixer.v', str(sw.QSF)}
    if {n for n in old if old[n] != current[n]} != expected:
        raise ValueError('Unexpected changed source')
    if any(current[n] != h for n, h in profile['qualified_changed_inputs'].items()):
        raise ValueError('Frozen candidate differs from exact reviewed profile inputs')
    if manifest['protected_sha256'] != base['protected_sha256']:
        raise ValueError('Protected CPU/PLL/SDC inputs changed')
    targets = load(HERE.parents[1] / 'timing-next/task-scope.json')['dock_video_target_inputs']
    if len(targets) != 89 or any(current[n] != h for n, h in targets.items()):
        raise ValueError('Dock/video target inputs changed')
    if manifest['sdram_write_buffer_storage'] != dict(present=True, target='*sdram_axi_slave|wbuf*',
            effective='M10K', assignments=[dict(target='*sdram_axi_slave|wbuf*', value='M10K')]):
        raise ValueError('SDRAM write-buffer storage manifest changed')
    if manifest['recipe_sha256'] != PINS:
        raise ValueError('Recipe inventory mismatch')


def audit(trial, partial=False, profile_path=HERE / 'profile-fbwq-pos-wbuf.json'):
    trial = Path(trial).resolve()
    profile_path = Path(profile_path).resolve()
    profile = read_profile(profile_path)
    sw = driver(trial)
    manifest = sw.verify(trial)
    check_source(sw, trial, manifest, profile)
    map_receipt = load(trial / 'map-receipt.json')
    if map_receipt.get('state') != 'complete' or map_receipt['frozen_sha256'] != profile['source_sha256']:
        raise ValueError('No complete source-bound map')
    if sw.source_changes(trial / 'work/master', manifest) or sw.mapped_inventory(trial / 'work/master') != map_receipt['mapped_database_sha256']:
        raise ValueError('Mapped master changed')
    complete = [seed for seed in range(1, 31) if (trial / 'seeds' / f'seed_{seed:02}/result.json').exists()]
    pending = sorted(set(range(1, 31)) - set(complete))
    if pending and not partial:
        raise ValueError('Final audit requires all30 attempted seeds: missing ' + str(pending))
    rows, row_pins, summaries = [], {}, []
    for seed in complete:
        seed_root = trial / 'seeds' / f'seed_{seed:02}'
        before = sha(seed_root / 'result.json')
        row = sw.verified_result(trial, seed, manifest)
        if row.get('seed') != seed or row.get('state') not in ('complete', 'failed'):
            raise ValueError('Incomplete or mislabeled seed receipt')
        if (row.get('map_receipt_sha256') is not None or row['state'] == 'complete') and row.get('map_receipt_sha256') != sha(trial / 'map-receipt.json'):
            raise ValueError('Seed did not use the pinned master map')
        qsf = sw.qsf_seed((trial / 'frozen' / sw.QSF).read_text(), seed)
        if (row.get('qsf_sha256') is not None or row['state'] == 'complete') and row.get('qsf_sha256') != hashlib.sha256(qsf.encode()).hexdigest():
            raise ValueError('Seed QSF is not the exact frozen QSF plus selected seed')
        if before != sha(seed_root / 'result.json'):
            raise ValueError('Seed changed during audit')
        row_pins[str(seed)] = before
        rows.append(row)
        keys = ['seed', 'state', 'valid_reports', 'error', 'resources',
                'minimum_main_restricted_fmax_mhz', 'timing_closed_at_configured_100_mhz',
                'eligible_above_90_mhz_estimate', 'nonsetup_clean', 'nonmain_setup_clean',
                'cross_clock_setup_clean', 'input_setup_clean', 'bitstream_sha256']
        summaries.append({k: row[k] for k in keys if k in row})
    selection = None
    physical = None
    if not partial:
        selection = sw.results.select(rows)
        for name, expected in [('results.json', rows), ('selection.json', selection)]:
            if (trial / name).exists() and load(trial / name) != expected:
                raise ValueError('Runner summary differs from independent all30 reparse: ' + name)
        winner = selection['selected_seed']
        if winner is not None:
            seed_root = trial / 'seeds' / f'seed_{winner:02}'
            attempt = seed_root / load(seed_root / 'latest.json')['attempt']
            with tarfile.open(attempt / 'quartus-reports.tar.gz') as tar:
                data = tar.extractfile(str(sw.PROJECT / 'output_files/ap_core.fit.rpt')).read()
            physical = ram_placements(data.decode(errors='replace'), profile['ram_expectations'])
    return dict(passed=True, kind='partial-independent-audit' if partial else 'full30-independent-audit',
                source_sha256=profile['source_sha256'], profile_name=profile['name'],
                profile_sha256=sha(profile_path), profile=profile,
                configured_mhz=100, saved_seed=2, completed_seeds=complete,
                pending_seeds=pending, all30_attempted=not pending, selection=selection,
                winning_physical_ram_placements=physical, rows=summaries, result_sha256=row_pins,
                recipe_sha256=PINS, manifest_sha256=sha(trial / 'manifest.json'),
                map_receipt_sha256=sha(trial / 'map-receipt.json'),
                no_quartus_launched=True, no_source_or_result_edits=True, deployed=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trial', type=Path)
    parser.add_argument('--partial', action='store_true')
    parser.add_argument('--profile', type=Path, default=HERE / 'profile-fbwq-pos-wbuf.json')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('Audit output must be new')
    result = audit(args.trial, args.partial, args.profile)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['passed', 'kind', 'completed_seeds', 'pending_seeds', 'selection']}, indent=2))
    print('Audit SHA256:', sha(args.output))


if __name__ == '__main__':
    main()
