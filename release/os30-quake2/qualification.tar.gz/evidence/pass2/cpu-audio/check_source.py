#!/usr/bin/env python3
"""Check the sole storage-implementation annotation change against deployed RTL."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PARENT = ROOT / 'timing-next/physical-corrected-cache-mixer/frozen/src/fpga/common/os30/audio_mixer.v'
OLD = b'(* ramstyle = "MLAB" *) reg [21:0] pos_latch [0:31];'
NEW = b'(* ramstyle = "M10K" *) reg [21:0] pos_latch [0:31];'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    old = PARENT.read_bytes()
    new = (HERE / 'audio_mixer.v').read_bytes()
    assert sha(old) == '9e4028bc2d32fa17d74d821f40b16daaf1cc6eed4f3383e23f22e12e3944255c'
    assert sha(new) == '2e2b85d417c9a620682d9376abd6ac73ad506a15629f70662f617cf768b55829'
    assert old.count(OLD) == 1 and new.count(NEW) == 1
    assert new.replace(NEW, OLD) == old
    assert old.count(b'pos_latch[cur_voice]  <= cur_pos_int;') == 1
    assert old.count(b'pos_readback_r <= pos_latch[voice_sel_rd];') == 1
    parent_reference = (ROOT / 'timing-next/mixer-loop-valid-v2/lockstep-v1/reference.log').read_text()
    current_reference = (HERE / 'tests-v1/reference.log').read_text()
    # The parent adds its paired-monitor footer; the public outputs are exact.
    assert parent_reference.startswith(current_reference)
    result = {
        'passed': True,
        'parent_sha256': sha(old),
        'candidate_sha256': sha(new),
        'source_reconstruction': 'Replace exactly one full32 pos_latch M10K attribute with MLAB: byte-identical deployed RTL.',
        'functional_source_identity': True,
        'new_behavioral_cycles': 0,
        'reference_output_and_processing_cycles_exact_parent': True,
        'reference_log_sha256': sha(current_reference.encode()),
        'tests_receipt_sha256': sha((HERE / 'tests-v1/receipt.json').read_bytes()),
        'limits': [
            'RTL simulation does not model synthesis RAM attributes.',
            'Physical memory mapping and read-during-write parameters require independent mapped-netlist inspection.',
            'No fitted timing, resource improvement or FPS claim.'
        ],
    }
    (HERE / 'source-identity.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
