Quake2 compact audio pass 2: position readback storage

The full 32-voice position snapshot bank moves from MLAB storage to M10K.
This is one synthesis attribute change in the deployed mixer. CPU ISA,
audio voices/formats/rates/loops/ramps/groups, Dock, audio scheduling and
all executable RTL remain unchanged. The separate MIXER_LITE branch is
unchanged. No no_rw_check attribute was added.

Candidate audio_mixer.v:
  2e2b85d417c9a620682d9376abd6ac73ad506a15629f70662f617cf768b55829
Deployed parent:
  9e4028bc2d32fa17d74d821f40b16daaf1cc6eed4f3383e23f22e12e3944255c

check_source.py reconstructs the deployed source byte for byte by undoing
the single attribute. The existing component tests pass 177 inherited
checks and 18,432 independent PCM samples in 96 scenarios. The reference
includes 2,048 position reads and 64 IRQ/readback cases. Output and
22,412,815 processing cycles are identical to the deployed mixer receipt.
The expensive capacity matrix was not repeated for an attribute-only
change with identical executable RTL.

check_mapping.py inspects the combined candidate's actual Quartus map.
It confirms a simple-dual-port 32x22 M10K with registered read address,
unregistered output and OLD_DATA mixed-port read-during-write behavior.
This retains one clock of read latency, absorbing the 22 fabric readback
registers into the memory. The old MLAB had unregistered address plus a
registered output; its collision mode was DONT_CARE. The new OLD_DATA
mode implements the unchanged RTL's nonblocking read/write semantics.
Physical collision values from the old DONT_CARE implementation are not
claimed bit-for-bit defined or equivalent.

These gates do not establish fitted timing, an FPGA resource saving after
placement, or an FPS improvement. Root owns the combined physical sweep.
Simulation does not model ramstyle; mapped-parameter inspection provides
the separate inference/latency/collision check.

Rerun source and map inspections from the repository root:
  python3 docs/measurements/quake2-tiny-audio-20261013/pass2/cpu-audio/check_source.py
  python3 docs/measurements/quake2-tiny-audio-20261013/pass2/cpu-audio/check_mapping.py

Component replay (use a new output directory):
  python3 docs/measurements/quake2-tiny-audio-20261013/tests/run.py \
    docs/measurements/quake2-tiny-audio-20261013/pass2/cpu-audio/audio_mixer.v \
    /tmp/quake2-pass2-audio-tests --skip-capacity

guard-independent-review.json is a separate independent review of the
narrow sweep recipe change permitting the existing SDRAM write buffer's
MLAB-to-M10K mapping. All 39 offline recipe tests passed; the timing
collector/parser and acceptance thresholds were unchanged.
