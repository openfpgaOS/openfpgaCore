#!/usr/bin/env python3
"""Inspect existing Quartus reports; this script launches no compiler or fitter."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
REL = Path('work/master/src/fpga/targets/pocket/output_files/ap_core.map.rpt')
PARENT = ROOT / 'timing-next/physical-corrected-cache-mixer' / REL
CANDIDATE = ROOT / 'pass2/full-sweep' / REL


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract(path, kind):
    text = path.read_text()
    marker = 'Parameter Settings for Inferred Entity Instance: core_top:ic|audio_mixer:audio_mixer_inst|' + kind + ':pos_latch_rtl_0 ;'
    start = text.index(marker)
    end = text.index('Note:', start)
    excerpt = text[start:end]
    params = {}
    for line in excerpt.splitlines():
        match = re.match(r'^;\s*([A-Z0-9_]+)\s*;\s*([^;]*?)\s*;', line)
        if match:
            params[match[1]] = match[2]
    summary = next(line for line in text.splitlines()
                   if '|audio_mixer:audio_mixer_inst|' in line and ':pos_latch_rtl_0|' in line
                   and 'Simple Dual Port' in line)
    return params, excerpt, summary


def main():
    old, old_excerpt, old_summary = extract(PARENT, 'altdpram')
    new, new_excerpt, new_summary = extract(CANDIDATE, 'altsyncram')
    assert old['WIDTH'] == new['WIDTH_A'] == new['WIDTH_B'] == '22'
    assert old['NUMWORDS'] == new['NUMWORDS_A'] == new['NUMWORDS_B'] == '32'
    assert old['RDADDRESS_REG'] == 'UNREGISTERED'
    assert old['OUTDATA_REG'] == 'OUTCLOCK'
    assert old['READ_DURING_WRITE_MODE_MIXED_PORTS'] == 'DONT_CARE'
    for key, value in {
        'OPERATION_MODE': 'DUAL_PORT', 'RAM_BLOCK_TYPE': 'M10K',
        'ADDRESS_REG_B': 'CLOCK0', 'OUTDATA_REG_B': 'UNREGISTERED',
        'READ_DURING_WRITE_MODE_MIXED_PORTS': 'OLD_DATA',
        'ADDRESS_ACLR_B': 'NONE', 'OUTDATA_ACLR_B': 'NONE',
        'INIT_FILE': 'UNUSED',
    }.items():
        assert new[key] == value, (key, new[key])
    assert '; M10K block ;' in new_summary
    assert '; MLAB ' in old_summary
    for label, excerpt, summary in [('parent', old_excerpt, old_summary), ('candidate', new_excerpt, new_summary)]:
        (HERE / (label + '-pos-latch-map.txt')).write_text(summary + '\n\n' + excerpt)
    manifest = ROOT / 'pass2/full-sweep/manifest.json'
    result = {
        'passed': True,
        'frozen_source_sha256': json.loads(manifest.read_text())['frozen_sha256'],
        'parent_report': str(PARENT.relative_to(ROOT)), 'parent_report_sha256': sha(PARENT),
        'candidate_report': str(CANDIDATE.relative_to(ROOT)), 'candidate_report_sha256': sha(CANDIDATE),
        'candidate_mixer_sha256': sha(HERE / 'audio_mixer.v'),
        'parent_parameters': old, 'candidate_parameters': new,
        'parent_summary': old_summary, 'candidate_summary': new_summary,
        'read_latency': {
            'parent': 'One clock: asynchronous MLAB read followed by registered output.',
            'candidate': 'One clock: registered M10K read address and unregistered RAM output.',
            'added_cycles': 0,
        },
        'collision_semantics': {
            'rtl': 'Concurrent same-address read receives old data (nonblocking clocked read/write).',
            'parent_mapping': 'DONT_CARE. Physical collision output was not guaranteed by this parameter.',
            'candidate_mapping': 'OLD_DATA, matching the unchanged RTL; no weakened collision contract.',
        },
        'resource_observation': '704 bits move from a 32x22 MLAB bank to M10K. The 22 fabric output FFs are absorbed into the synchronous RAM. Physical block/LAB totals require the fitter.',
        'limits': ['Report/parameter inspection, not post-route gate-level simulation.',
                   'No fitted timing or game performance claim.'],
    }
    (HERE / 'mapping-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'passed': True, 'frozen_source_sha256': result['frozen_source_sha256'],
                      'receipt_sha256': sha(HERE / 'mapping-review.json')}, indent=2))


if __name__ == '__main__':
    main()
