#!/usr/bin/env python3
"""Verify package and stage core/app sources into a new directory safely."""
import argparse
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from verify import archive_files, cleanpath, load, verify


def stage(package, destination):
    package, destination = cleanpath(package), cleanpath(destination)
    verify(package)
    if destination.exists() or destination.is_relative_to(package) or package.is_relative_to(destination):
        raise ValueError('Choose a new directory outside the package')
    core = archive_files(package / 'core/source.tar.gz')
    app = archive_files(package / 'app/source.tar.gz')
    modes = load(package / 'app/manifest.json')['source']
    destination.mkdir(parents=True)
    for component, files in [('core', core), ('app', app)]:
        for name, data in files.items():
            path = destination / component / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            if component == 'app':
                path.chmod(modes[name]['mode'] & 0o777)
    print(destination)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('package', type=Path)
    p.add_argument('destination', type=Path)
    a = p.parse_args()
    stage(a.package, a.destination)
