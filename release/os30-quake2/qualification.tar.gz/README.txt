Quake2 tiny audio: completed 1–30 timing sweep

Profile: texture-requests-pos-wbuf-m10k
Frozen 128-file core source: f3685d901a8688ff9c62cb9e4259a61d04e45fe646532ebc6c744e617df81b1b
Selected seed: 16
Worst-corner restricted main Fmax estimate: 90.69 MHz
Configured main clock: 100 MHz
Timing closed at configured 100 MHz: false
Resources: {"ALMs": {"available": 18480, "used": 17995}, "DSPs": {"available": 66, "used": 42}, "LABs": {"available": 1848, "used": 1848}, "M10Ks": {"available": 308, "used": 308}}

All 30 seeds were attempted on this exact source. Selection reuses the
unchanged timing policy: prefer 100 MHz closure, then the highest worst-
corner estimate strictly above 90 MHz with clean used input/cross-clock,
non-main-clock and nonsetup checks. A >90 MHz estimate is not a claim of
100 MHz timing closure or a changed runtime clock. Raw reports retain
the disconnected SDRAM DDIO high-capture paths and their topology proof;
only the proven unused paths are excluded from used-interface checks.

The source changes only RAM storage attributes and the existing SDRAM
write-buffer RAMSTYLE assignment. Full CPU ISA, all 32 audio voices,
all audio groups/formats/loops/rates/ramps, Dock/video and processing
cycles remain. Changed files versus the previously deployed general core:
  src/fpga/common/os30/audio_mixer.v
  src/fpga/common/os30/gpu_core.v
  src/fpga/targets/pocket/ap_core.qsf

Application app/app.elf is unchanged (10581bdb...). Its full 731-input
source archive and prior clean-build receipt are included. No commercial
game PAK/map/audio data, compiler, Quartus installation, or proprietary
simulation model is bundled. Prior renderer/worker features are inherited
from the deployed Quake2 native6/tiny-audio package; included pass2 gates
cover the new mapping changes. This package itself has not been deployed;
this selected image has no new physical Pocket audio/FPS measurement.

Verify using Python3, with no compiler or hardware access:
  python3 verify.py .

Verification checks all 128 source hashes, the exact deployed baseline,
all 731 app source hashes, all 30 original seed receipts and report hashes,
four-corner report reparsing, full-sweep selection, actual selected RAM
placements, and byte reversal of the selected raw RBF. Original receipts
are unchanged. Only nonselected binary images and SOFs are omitted;
sweep/omitted-binaries.json records their original paths/hashes. Failed
attempt reports, errors and logs remain included. Manifest hashes detect
changes; they are not a publisher signature.

Stage checked sources into a new directory:
  python3 stage.py . /tmp/quake2-tiny-audio-sweep-build

Build the core with the same recorded Quartus 25.1std environment. The
frozen QSF saves seed 2 for the single mapping pass. Map it unchanged:
  cd /tmp/quake2-tiny-audio-sweep-build/core/src/fpga/targets/pocket
  quartus_map ap_core --write_settings_files=off --parallel=4

After mapping, change ONLY the existing QSF `set_global_assignment -name
SEED 2` line to seed 16. Reproduce the selected fitting attempt:
  quartus_fit ap_core --recompile=off --write_settings_files=off --seed=16 --parallel=4
  quartus_asm ap_core
  quartus_sta ap_core

Run the bundled recipes/report_sweep_timing.tcl at all four corners as
shown by the selected attempt receipt, then reparse using results.py.
The fitter is placement-sensitive; a rebuilt image needs fresh timing
qualification. Do not label a clean compile as equivalent timing closure.
Only after successful qualification reverse bits within each raw RBF
byte for Pocket; the included core/os30.rbf_r is already reversed.

Application reproduction: app/manifest.json records the pinned compiler,
source date epoch and expected ELF; app/clean-rebuild.json records the
successful clean rebuild. Its archive includes SDK objects/libraries
from the prior approved source inventory. Do not rebuild the game with
different SDK binaries and assume it still matches this paired ELF.

Sweep orchestration and map/fitter/STA commands are retained under sweep/
and recipes/. This is a complete sweep package, separate from the prior
source-only 30-seed experiment and earlier targeted-seed timing package.

The texture queue collision/stall test can be rerun directly using the
three bundled queue-lockstep/*.sv files under
evidence/pass2/gpu/texture-request. Compile them with Verilator --binary
--timing --assert --top-module tb -DINCLUDE_TEX_QUEUE_MLAB, using a new
--Mdir outside this package, then run that directory's Vtb. The candidate
deliberately poisons same-address raw RAM reads; forwarding must still
preserve every observable queue output and state.

Other measurement helper scripts retain repository-relative paths and
are included as exact recipes, not advertised as standalone commands.
Full GPU replay receipts refer to external native6 captures; prior
write-path controls and large capture data are not duplicated here.
