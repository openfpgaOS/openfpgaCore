#!/usr/bin/env python3
"""Verify the complete 1–30 sweep delivery offline; never run Quartus or deploy."""
import hashlib
import importlib.util
import json
import re
import stat
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True
APP_SHA = '10581bdb05e98c87dcd08abb2798549267793920f6c91e1c6be964b0dd9fb636'
APP_SOURCE_SHA = '0533dfc53044f1f344fda8b5c493ca93ac94bf3d2bfce1ed34b01e8b5c67f658'
APP_MANIFEST_SHA = '40ce036cdd3ac724868217d4f763185100b5dd445ac28e4a8d7b729c8de9d8a0'
BASE_SHA = '9a4e8b063a2ac21c59d7dbfc47335155760666d22b10095dda27559573329a87'
BASE_ARCHIVE = '481cddef03ffbe95f749179924db1e70d8242121d5475088789f028ca21fc3f4'
PINS = {'sweep.py': '04c5cb4ea77e6f3b455405e3bff71cd803345dcdfec47b7d02175def2e9c6a80',
        'results.py': '192828cad6b134c0f6cacfd484611e1ec9db5ab27cf379974bd737296d4f110b',
        'report_sweep_timing.tcl': '2c66004df7b54c2e62a0c47ae976cf7c61da684ec034a169cb077ca00cdca34e'}
PROJECT = 'src/fpga/targets/pocket/'
QSF = PROJECT + 'ap_core.qsf'
AUDIO = 'src/fpga/common/os30/audio_mixer.v'
GPU = 'src/fpga/common/os30/gpu_core.v'
BINARY_NAMES = {'ap_core.rbf', 'ap_core.sof', 'os30.rbf_r'}
SEEDS = list(range(1, 31))
# A new source may be packaged only with an independently reviewed proof plan.
# This exact plan binds all61 functional/source/inference proof files, not just
# the physical audit profile. Empty or reduced inventories are never accepted.
QUALIFIED_PLANS = {
    'f3685d901a8688ff9c62cb9e4259a61d04e45fe646532ebc6c744e617df81b1b':
        'd10e128975dea990535afd6dfa65e8fb560e9b7962ddd4e50c7f0c0efd4ed78c',
}


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(files):
    return digest(json.dumps(files, sort_keys=True, separators=(',', ':')).encode())


def safe_name(name):
    p = PurePosixPath(name)
    if not name or p.is_absolute() or '..' in p.parts or str(p) != name or '\\' in name:
        raise ValueError('Unsafe relative path: ' + name)
    return name


def cleanpath(path):
    path = Path(path).absolute()
    if '..' in path.parts or any(p.is_symlink() for p in [path, *path.parents]):
        raise ValueError('Unsafe or symlink path: ' + str(path))
    return path.resolve()


def inventory(root):
    root = cleanpath(root)
    answer = {}
    for p in sorted(root.rglob('*')):
        mode = p.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        if not stat.S_ISREG(mode):
            raise ValueError('Only regular files are allowed: ' + str(p))
        answer[safe_name(p.relative_to(root).as_posix())] = sha(p)
    return answer


def archive_files(path):
    """Read checked regular members only; never extract archive paths to disk."""
    answer = {}
    total = 0
    with tarfile.open(path) as tar:
        for member in tar:
            name = safe_name(member.name)
            total += member.size
            if not member.isfile() or name in answer or member.size < 0 or total > 512 * 1024 * 1024:
                raise ValueError('Unsafe/duplicate/oversize archive member: ' + name)
            stream = tar.extractfile(member)
            if stream is None:
                raise ValueError('Unreadable archive member: ' + name)
            answer[name] = stream.read()
    return answer


def parser(root):
    for name, expected in PINS.items():
        if sha(root / 'recipes' / name) != expected:
            raise ValueError('Timing recipe changed: ' + name)
    spec = importlib.util.spec_from_file_location('pass2_pinned_results', root / 'recipes/results.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def qsf_seed(text, seed):
    changed, count = re.subn(r'^set_global_assignment -name SEED \d+[ \t]*$',
                            'set_global_assignment -name SEED ' + str(seed), text, flags=re.M)
    if count != 1:
        raise ValueError('Expected one explicit saved seed')
    return changed


def check_source(root, plan):
    manifest = load(root / 'sweep/manifest.json')
    files = archive_files(root / 'core/source.tar.gz')
    pins = {n: digest(data) for n, data in files.items()}
    if len(files) != 128 or pins != manifest['source_sha256'] or fingerprint(pins) != manifest['frozen_sha256']:
        raise ValueError('Frozen128 source inventory/fingerprint mismatch')
    if manifest['frozen_sha256'] != plan['source_sha256'] or manifest['seeds'] != SEEDS:
        raise ValueError('Source profile/full30 scope mismatch')
    if manifest['configured_mhz'] != 100 or manifest['saved_seed'] != 2 or manifest['recipe_sha256'] != PINS:
        raise ValueError('Clock/seed/recipe configuration mismatch')
    if sha(root / 'baseline/source.tar.gz') != BASE_ARCHIVE:
        raise ValueError('Deployed baseline archive changed')
    baseline = archive_files(root / 'baseline/source.tar.gz')
    old = {n: digest(data) for n, data in baseline.items()}
    if fingerprint(old) != BASE_SHA or set(old) != set(pins):
        raise ValueError('Deployed baseline mismatch')
    changes = {n: pins[n] for n in pins if old[n] != pins[n]}
    if changes != plan['changed_source_sha256'] or set(changes) - {GPU, AUDIO, QSF}:
        raise ValueError('Unapproved change: CPU/Dock/clock/features must remain intact')
    for name in [GPU, AUDIO]:
        before, after = baseline[name], files[name]
        # Only RAM storage attributes may differ, without changing no_rw_check.
        strip = lambda text: re.sub(rb'\(\* ramstyle = "(?:MLAB|M10K)(, no_rw_check)?" \*\)', rb'RAM_STORAGE\1', text)
        if strip(before) != strip(after):
            raise ValueError('Executable audio/GPU RTL changed: ' + name)
    normalized = lambda text: [line.strip().replace('RAMSTYLE_ATTRIBUTE M10K -to *sdram_axi_slave|wbuf*',
                                                   'RAMSTYLE_ATTRIBUTE MLAB -to *sdram_axi_slave|wbuf*')
                               for line in text.decode().splitlines() if line.strip() and not line.lstrip().startswith('#')]
    if normalized(baseline[QSF]) != normalized(files[QSF]):
        raise ValueError('QSF changed beyond reviewed SDRAM buffer storage')
    return manifest, files


def parse_attempt(root, attempt, row, measured_parser, omitted, selected):
    actual = inventory(attempt)
    actual.pop('receipt.json', None)
    relative = attempt.relative_to(root).as_posix()
    skipped = omitted.get(relative, {})
    for name, expected in skipped.items():
        if name not in BINARY_NAMES or name in actual or row['evidence_sha256'].get(name) != expected:
            raise ValueError('Invalid omitted-binary receipt: ' + relative)
        if selected and name != 'ap_core.sof':
            raise ValueError('Selected raw/reversed RBF must be retained')
    if {**actual, **skipped} != row['evidence_sha256']:
        raise ValueError('Original attempt evidence hash inventory differs: ' + relative)
    reports = archive_files(attempt / 'quartus-reports.tar.gz')
    if {n: digest(data) for n, data in reports.items()} != row['quartus_report_sha256']:
        raise ValueError('Original Quartus report archive differs: ' + relative)
    if row.get('valid_reports'):
        if row['state'] != 'complete':
            raise ValueError('Failed attempt cannot have valid timing reports')
        with tempfile.TemporaryDirectory(prefix='q2-sweep-report-') as tmp:
            project = Path(tmp)
            (project / 'output_files').mkdir()
            for name in ['ap_core.fit.rpt', 'ap_core.fit.summary']:
                (project / 'output_files' / name).write_bytes(reports[PROJECT + 'output_files/' + name])
            measured = measured_parser.parse(project, attempt / 'timing')
        if any(row.get(key) != value for key, value in measured.items()):
            raise ValueError('Stored timing differs from raw reparse: ' + relative)
    return reports


def verify_sweep(root, manifest, files, audit, plan):
    measured_parser = parser(root)
    mapping = load(root / 'sweep/map-receipt.json')
    if mapping['state'] != 'complete' or mapping['frozen_sha256'] != manifest['frozen_sha256'] or mapping['post_map_source_changes']:
        raise ValueError('Mapping did not preserve frozen source')
    omitted = load(root / 'sweep/omitted-binaries.json')
    selection = load(root / 'sweep/selection.json')
    winner = selection['selected_seed']
    if type(winner) is not int or winner not in SEEDS:
        raise ValueError('No eligible selected image; source-only export requires a separate mode')
    seeds_root = root / 'sweep/seeds'
    if {p.name for p in seeds_root.iterdir()} != {f'seed_{s:02}' for s in SEEDS}:
        raise ValueError('Must preserve exactly seeds1–30')
    rows, seen_omitted, winner_reports = [], set(), None
    for seed in SEEDS:
        folder = seeds_root / f'seed_{seed:02}'
        latest = load(folder / 'latest.json')['attempt']
        if not re.fullmatch(r'attempt_\d+', latest):
            raise ValueError('Unsafe attempt pointer')
        row = load(folder / 'result.json')
        if row != load(folder / latest / 'receipt.json'):
            raise ValueError('Latest result does not match original attempt receipt')
        attempts = sorted(p for p in folder.iterdir() if p.is_dir())
        if not attempts or any(not re.fullmatch(r'attempt_\d+', p.name) for p in attempts):
            raise ValueError('Invalid attempt directory')
        for attempt in attempts:
            item = load(attempt / 'receipt.json')
            if item['seed'] != seed or item['state'] not in ['complete', 'failed'] or item['frozen_sha256'] != manifest['frozen_sha256']:
                raise ValueError('Unfinished/mislabeled source-bound attempt')
            for key, expected in [('map_receipt_sha256', sha(root / 'sweep/map-receipt.json')),
                                  ('qsf_sha256', digest(qsf_seed(files[QSF].decode(), seed).encode()))]:
                if (key in item or item['state'] == 'complete') and item.get(key) != expected:
                    raise ValueError('Attempt map/QSF binding changed')
            chosen = seed == winner and attempt.name == latest
            reports = parse_attempt(root, attempt, item, measured_parser, omitted, chosen)
            if chosen:
                winner_reports = reports
                raw, reverse = (attempt / 'ap_core.rbf').read_bytes(), (attempt / 'os30.rbf_r').read_bytes()
                table = bytes(int(f'{n:08b}'[::-1], 2) for n in range(256))
                if raw.translate(table) != reverse or digest(raw) != item['raw_rbf_sha256'] or digest(reverse) != item['bitstream_sha256']:
                    raise ValueError('Selected raw/RBF reversal mismatch')
                if (root / 'core/os30.rbf_r').read_bytes() != reverse:
                    raise ValueError('Exported core is not selected artifact')
            relative = attempt.relative_to(root).as_posix()
            if relative in omitted:
                seen_omitted.add(relative)
        rows.append(row)
    if set(omitted) != seen_omitted or rows != load(root / 'sweep/results.json'):
        raise ValueError('Attempt omissions or aggregate results mismatch')
    recalculated = measured_parser.select(rows)
    if recalculated != selection:
        raise ValueError('All30 raw results select a different winner')
    status = load(root / 'sweep/status.json')
    if status.get('state') != 'complete' or status.get('seeds_completed') != 30 or status.get('selection') != selection:
        raise ValueError('Sweep is unfinished')
    if audit.get('passed') is not True or audit.get('kind') != 'full30-independent-audit' or not audit.get('all30_attempted'):
        raise ValueError('Missing completed independent full30 audit')
    if audit['source_sha256'] != manifest['frozen_sha256'] or audit['selection'] != selection or audit['completed_seeds'] != SEEDS or audit['pending_seeds']:
        raise ValueError('Independent audit selection/source mismatch')
    if audit['manifest_sha256'] != sha(root / 'sweep/manifest.json') or audit['map_receipt_sha256'] != sha(root / 'sweep/map-receipt.json'):
        raise ValueError('Independent audit input pins mismatch')
    for seed in SEEDS:
        if audit['result_sha256'][str(seed)] != sha(seeds_root / f'seed_{seed:02}/result.json'):
            raise ValueError('Independent seed audit pin mismatch')
    physical = audit.get('winning_physical_ram_placements')
    profile_path = safe_name(plan['audit_profile'])
    profile = load(root / 'evidence' / profile_path)
    if profile['source_sha256'] != manifest['frozen_sha256'] or profile['qualified_changed_inputs'] != plan['changed_source_sha256']:
        raise ValueError('Audit profile belongs to a different source')
    if audit.get('profile_sha256') != sha(root / 'evidence' / profile_path) or audit.get('profile') != profile:
        raise ValueError('Independent audit profile mismatch')
    if not physical or set(physical) != set(profile['ram_expectations']):
        raise ValueError('Missing actual fitted RAM placement proof')
    fitted = winner_reports[PROJECT + 'output_files/ap_core.fit.rpt'].decode(errors='replace')
    cells = [[s.strip() for s in line.split(';')[1:-1]] for line in fitted.splitlines()]
    for label, memory in physical.items():
        owner, name, depth, width = profile['ram_expectations'][label]
        if memory['raw_cells'] not in cells or memory['memory_type'] != 'M10K block' or memory['physical_blocks'] != 1 or memory['mlabs'] != 0 or not memory['port_b_address_registered'] or memory['port_b_output_registered']:
            raise ValueError('Independent physical RAM placement differs from raw fitter report')
        if owner not in memory['instance'] or name not in memory['instance'] or memory['port_a_depth'] != depth or memory['port_a_width'] != width:
            raise ValueError('Fitted memory is not the qualified storage bank')
        raw = memory['raw_cells']
        if (raw[0] != memory['instance'] or raw[1:4] != ['M10K block', 'Simple Dual Port', 'Single Clock']
                or list(map(int, raw[4:8])) != [depth, width, depth, width]
                or raw[10:12] != ['yes', 'no'] or raw[18:20] != ['1', '0']
                or not re.search(r'\bM10K_X\d+_Y\d+_N\d+\b', raw[21])):
            raise ValueError('Raw physical RAM fields do not satisfy qualified profile')
    selected = rows[winner - 1]
    if not selected['eligible_above_90_mhz_estimate'] or selected['minimum_main_restricted_fmax_mhz'] <= 90:
        raise ValueError('Selected image misses strict >90MHz gate')
    return selected, selection


def verify(root):
    root = cleanpath(root)
    package = load(root / 'manifest.json')
    actual = inventory(root)
    actual.pop('manifest.json')
    if actual != package['files'] or package['kind'] != 'complete30-sweep-qualification':
        raise ValueError('Package inventory/scope changed')
    plan = load(root / 'evidence-plan.json')
    if QUALIFIED_PLANS.get(plan.get('source_sha256')) != sha(root / 'evidence-plan.json'):
        raise ValueError('Missing or changed qualified functional proof plan')
    for name, expected in plan['files'].items():
        if sha(root / 'evidence' / safe_name(name)) != expected:
            raise ValueError('Evidence pin changed: ' + name)
    if sha(root / 'app/app.elf') != APP_SHA or sha(root / 'app/source.tar.gz') != APP_SOURCE_SHA or sha(root / 'app/manifest.json') != APP_MANIFEST_SHA:
        raise ValueError('Paired application changed')
    app_source = {n: digest(data) for n, data in archive_files(root / 'app/source.tar.gz').items()}
    if app_source != {n: item['sha256'] for n, item in load(root / 'app/manifest.json')['source'].items()}:
        raise ValueError('Application source archive mismatch')
    source, files = check_source(root, plan)
    row, selection = verify_sweep(root, source, files, load(root / 'independent-audit.json'), plan)
    q = load(root / 'qualification.json')
    expected = dict(source_sha256=source['frozen_sha256'], selected_seed=row['seed'], selection=selection,
                    configured_mhz=100, minimum_main_restricted_fmax_mhz=row['minimum_main_restricted_fmax_mhz'],
                    timing_closed_at_configured_100_mhz=row['timing_closed_at_configured_100_mhz'],
                    bitstream_sha256=row['bitstream_sha256'], app_sha256=APP_SHA, resources=row['resources'])
    if q != expected:
        raise ValueError('Qualification summary differs from raw evidence')
    outer = dict(source_sha256=q['source_sha256'], selected_seed=q['selected_seed'],
                 configured_mhz=100, app_sha256=APP_SHA, deployed=False)
    if any(package.get(key) != value for key, value in outer.items()):
        raise ValueError('Outer package metadata differs from verified qualification')
    return dict(passed=True, all30_attempted=True, selected_seed=row['seed'],
                fmax_mhz=q['minimum_main_restricted_fmax_mhz'], configured_mhz=100,
                timing_closed_at_configured_100_mhz=q['timing_closed_at_configured_100_mhz'])


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')), indent=2))
