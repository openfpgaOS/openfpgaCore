#!/usr/bin/env python3
"""Assemble a new complete-sweep package only after all30 attempts and audit."""
import argparse
import difflib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
MEAS = HERE.parents[1]
REPO = MEAS.parents[2]
PREVIOUS = REPO / 'tools/experiments/quake2_tiny_audio_timing_20261013'
APP_PACKAGE = REPO / 'tools/experiments/quake2_tiny_audio_20261013/app'
DEFAULT_OUTPUT = REPO / 'tools/experiments/quake2_tiny_audio_sweep_20261013'
sys.path.insert(0, str(HERE))
from verify import (APP_SHA, BINARY_NAMES, PINS, SEEDS, archive_files, cleanpath,
                    digest, inventory, load, safe_name, sha, verify)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def prepare(trial, plan_path, audit_path, output):
    """Write only a fresh staging directory. No compiler/source/sweep edits."""
    trial, plan_path, audit_path = map(cleanpath, [trial, plan_path, audit_path])
    manifest = load(trial / 'manifest.json')
    status = load(trial / 'status.json')
    selection = load(trial / 'selection.json')
    audit = load(audit_path)
    plan = load(plan_path)
    if manifest['seeds'] != SEEDS or status.get('state') != 'complete' or status.get('seeds_completed') != 30:
        raise ValueError('Wait for the completed full1–30 sweep')
    if selection.get('selected_seed') not in SEEDS or not selection.get('all_seeds_attempted'):
        raise ValueError('No qualified full-sweep winner')
    if plan['source_sha256'] != manifest['frozen_sha256'] or not audit.get('passed') or audit.get('selection') != selection:
        raise ValueError('Profile/audit does not match completed selection')
    # Inspect names before creating output; never follow evidence-plan escapes.
    for name, expected in plan['files'].items():
        path = cleanpath(MEAS / safe_name(name))
        if not path.is_relative_to(MEAS.resolve()) or sha(path) != expected:
            raise ValueError('Evidence changed or escaped: ' + name)
    if output.exists():
        raise ValueError('Staging output already exists')
    output.mkdir(parents=True)

    def copy(src, name):
        src = cleanpath(src)
        dst = output / safe_name(name)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not src.is_file():
            raise ValueError('Expected a regular input file: ' + str(src))
        shutil.copy2(src, dst)

    copy(trial / 'source.tar.gz', 'core/source.tar.gz')
    copy(PREVIOUS / 'core/source.tar.gz', 'baseline/source.tar.gz')
    copy(PREVIOUS / 'core/source-manifest.json', 'baseline/source-manifest.json')
    old, new = archive_files(output / 'baseline/source.tar.gz'), archive_files(output / 'core/source.tar.gz')
    changed = sorted(n for n in new if old.get(n) != new[n])
    patch = ''.join(''.join(difflib.unified_diff(old[n].decode().splitlines(True), new[n].decode().splitlines(True),
                       fromfile='a/' + n, tofile='b/' + n)) for n in changed)
    (output / 'core/source.patch').write_text(patch)
    copy(PREVIOUS / 'app/app.elf', 'app/app.elf')
    for name in ['source.tar.gz', 'manifest.json', 'clean-rebuild.json']:
        copy(APP_PACKAGE / name, 'app/' + name)
    for name in ['manifest.json', 'baseline-manifest.json', 'map-receipt.json', 'map.log',
                 'results.json', 'selection.json', 'status.json', 'run-configuration.json', 'events.jsonl']:
        copy(trial / name, 'sweep/' + name)
    map_report = trial / 'work/master/src/fpga/targets/pocket/output_files/ap_core.map.rpt'
    if map_report.is_file():
        copy(map_report, 'sweep/ap_core.map.rpt')
    winner = selection['selected_seed']
    omitted = {}
    for seed in SEEDS:
        folder = trial / 'seeds' / f'seed_{seed:02}'
        latest = load(folder / 'latest.json')['attempt']
        for name in ['latest.json', 'result.json']:
            copy(folder / name, f'sweep/seeds/seed_{seed:02}/' + name)
        for attempt in sorted(p for p in folder.iterdir() if p.is_dir()):
            prefix = f'sweep/seeds/seed_{seed:02}/' + safe_name(attempt.name)
            chosen = seed == winner and attempt.name == latest
            for name, expected in inventory(attempt).items():
                if name in BINARY_NAMES and (not chosen or name == 'ap_core.sof'):
                    omitted.setdefault(prefix, {})[name] = expected
                    continue
                copy(attempt / name, prefix + '/' + name)
            if chosen:
                copy(attempt / 'os30.rbf_r', 'core/os30.rbf_r')
    save(output / 'sweep/omitted-binaries.json', omitted)
    for name in PINS:
        copy(trial / 'recipes' / name, 'recipes/' + name)
    copy(plan_path, 'evidence-plan.json')
    copy(audit_path, 'independent-audit.json')
    for name in plan['files']:
        copy(MEAS / name, 'evidence/' + name)
    for name in ['verify.py', 'assemble.py', 'stage.py']:
        copy(HERE / name, name)
    row = load(trial / 'seeds' / f'seed_{winner:02}/result.json')
    qualification = dict(source_sha256=manifest['frozen_sha256'], selected_seed=winner, selection=selection,
         configured_mhz=100, minimum_main_restricted_fmax_mhz=row['minimum_main_restricted_fmax_mhz'],
         timing_closed_at_configured_100_mhz=row['timing_closed_at_configured_100_mhz'],
         bitstream_sha256=row['bitstream_sha256'], app_sha256=APP_SHA, resources=row['resources'])
    save(output / 'qualification.json', qualification)
    readme = (HERE / 'README.template.txt').read_text().format(seed=winner,
          fmax=row['minimum_main_restricted_fmax_mhz'],
          closed=str(row['timing_closed_at_configured_100_mhz']).lower(),
          source=manifest['frozen_sha256'], resources=json.dumps(row['resources'], sort_keys=True),
          changed='\n'.join('  ' + name for name in changed), profile=plan['profile_name'])
    (output / 'README.txt').write_text(readme)
    save(output / 'manifest.json', dict(kind='complete30-sweep-qualification',
         deployed=False, configured_mhz=100, source_sha256=manifest['frozen_sha256'],
         selected_seed=winner, app_sha256=APP_SHA, files=inventory(output)))
    return verify(output)


def assemble(trial, plan, audit, destination, export=False):
    destination = cleanpath(destination)
    trial = cleanpath(trial)
    if destination.exists() or any(destination == p or destination.is_relative_to(p) or p.is_relative_to(destination)
                                   for p in [PREVIOUS.resolve(), APP_PACKAGE.parent.resolve(), trial]):
        raise ValueError('Destination must be new and outside protected package/sweep trees')
    parent = destination.parent if export else None
    if export:
        parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.q2-sweep-stage-', dir=parent) as temp:
        stage = Path(temp) / 'package'
        result = prepare(trial, plan, audit, stage)
        if export:
            if destination.exists():
                raise ValueError('Destination appeared during validation')
            os.rename(stage, destination)
            result['manifest_sha256'] = sha(destination / 'manifest.json')
    return dict(result, exported=export, destination=str(destination) if export else None)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('trial', type=Path)
    p.add_argument('--evidence-plan', type=Path, required=True)
    p.add_argument('--audit', type=Path, required=True)
    p.add_argument('--output', type=Path, default=DEFAULT_OUTPUT)
    p.add_argument('--export', action='store_true', help='Create the new package after all checks; default is check-only')
    a = p.parse_args()
    print(json.dumps(assemble(a.trial, a.evidence_plan, a.audit, a.output, a.export), indent=2))
